import React from "react";
import {
  MDBCard,
  MDBCardOverlay,
  MDBCardBody,
  MDBCardImage,
  MDBRow,
  MDBCardTitle,
  MDBCardText,
  MDBCol,
} from "mdb-react-ui-kit";
import Card from "react-bootstrap/Card";
import Button from "@mui/material/Button";

export default function CentreofExcellence() {
  return (
    <div>
      <MDBCard  className="text-white">
        <MDBCardImage overlay src="../image/center_doctor_hero.png" alt="..." />
        <MDBCardOverlay></MDBCardOverlay>
      </MDBCard>
      <Card body>
        <MDBRow className="row-cols-2 row-cols-md-6 g-4">
          <MDBCol>
            <MDBCard
              className="h-100 shadow-inner"
              style={{ background: "white", color: "black",}}
            >
              <MDBCardBody
                className="img-fluid shadow-5-strong rounded-4"
                style={{ textAlign: "center" }}
              >
                <MDBCardImage
                  src="../image/lab.png"
                  fluid
                  alt="..."
                  style={{
                    maxWidth: "100%",
                    display: "block",
                    margin: "10px auto",
                  }}
                />
                <MDBCardTitle className="text-center mb-3">
                  Cancer Care
                </MDBCardTitle>
                <MDBCardText style={{ color: "black" }}>
                  Cancer care is a crucial aspect of healthcare that involves
                  the prevention, diagnosis, treatment, and supportive care for
                  individuals affected by cancer.
                </MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
          <MDBCol>
            <MDBCard
              className="h-100"
              style={{ background: "white", color: "black" }}
            >
              <MDBCardBody
                className="img-fluid shadow-5-strong rounded-4"
                style={{ textAlign: "center" }}
              >
                <MDBCardImage
                  src="../image/tmt.png"
                  fluid
                  alt="..."
                  style={{
                    maxWidth: "100%",
                    display: "block",
                    margin: "10px auto",
                  }}
                />
                <MDBCardTitle className="text-center mb-3">
                  Cardiology
                </MDBCardTitle>
                <MDBCardText style={{ color: "black" }}>
                  Cardiology is the branch of medicine that deals with heart
                  disorders, encompassing diagnosis, treatment, and prevention
                  of heart-related conditions.
                </MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
          <MDBCol>
            <MDBCard
              className="h-100"
              style={{ background: "white", color: "black" }}
            >
              <MDBCardBody
                className="img-fluid shadow-5-strong rounded-4"
                style={{ textAlign: "center" }}
              >
                <MDBCardImage
                  src="../image/Xray.png"
                  fluid
                  alt="..."
                  style={{
                    maxWidth: "100%",
                    display: "block",
                    margin: "10px auto",
                  }}
                />
                <MDBCardTitle className="text-center mb-3">
                  Cardiothoracic Vascular Surgery
                </MDBCardTitle>
                <MDBCardText style={{ color: "black" }}>
                  Cardiothoracic Vascular Surgery involves surgical
                  interventions on the heart, lungs, and blood vessels,
                  addressing complex conditions such as heart disease and
                  thoracic abnormalities.
                </MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
          <MDBCol>
            <MDBCard
              className="h-100"
              style={{ background: "white", color: "black" }}
            >
              <MDBCardBody
                className="img-fluid shadow-5-strong rounded-4"
                style={{ textAlign: "center" }}
              >
                <MDBCardImage
                  src="../image/tmt.png"
                  fluid
                  alt="..."
                  style={{
                    maxWidth: "100%",
                    display: "block",
                    margin: "10px auto",
                  }}
                />
                <MDBCardTitle className="text-center mb-3">
                  Gastrointestinal Scince
                </MDBCardTitle>
                <MDBCardText style={{ color: "black" }}>
                  Gastrointestinal Science is the field dedicated to studying
                  the digestive system, encompassing research, diagnosis, and
                  treatment of disorders affecting the stomach, intestines, and
                  associated organs.
                </MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
          <MDBCol>
            <MDBCard
              className="h-100"
              style={{ background: "white", color: "black" }}
            >
              <MDBCardBody
                className="img-fluid shadow-5-strong rounded-4"
                style={{ textAlign: "center" }}
              >
                <MDBCardImage
                  src="../image/radiology.png"
                  fluid
                  alt="..."
                  style={{
                    maxWidth: "100%",
                    display: "block",
                    margin: "10px auto",
                  }}
                />
                <MDBCardTitle className="text-center mb-3">
                  Nephrology
                </MDBCardTitle>
                <MDBCardText style={{ color: "black" }}>
                  Nephrology is the medical specialty focusing on the diagnosis
                  and treatment of kidney-related conditions and diseases.
                </MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
          <MDBCol>
            <MDBCard
              className="h-100"
              style={{ background: "white", color: "black" }}
            >
              <MDBCardBody
                className="img-fluid shadow-5-strong rounded-4"
                style={{ textAlign: "center" }}
              >
                <MDBCardImage
                  src="../image/pharmacy.png"
                  fluid
                  alt="..."
                  style={{
                    maxWidth: "100%",
                    display: "block",
                    margin: "10px auto",
                  }}
                />
                <MDBCardTitle className="text-center mb-3">
                  Neurology
                </MDBCardTitle>
                <MDBCardText style={{ color: "black" }}>
                  Neurology is the medical specialty concerned with the
                  diagnosis and treatment of disorders affecting the nervous
                  system, including the brain, spinal cord, and nerves.
                </MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
        </MDBRow>
        <MDBRow className="row-cols-1 row-cols-md-6 g-4">
          <MDBCol>
            <MDBCard
              className="h-100 shadow-inner"
              style={{ background: "white", color: "black" }}
            >
              <MDBCardBody
                className="img-fluid shadow-5-strong rounded-4"
                style={{ textAlign: "center" }}
              >
                <MDBCardImage
                  src="../image/operation_theatre.png"
                  fluid
                  alt="..."
                  style={{
                    maxWidth: "100%",
                    display: "block",
                    margin: "10px auto",
                  }}
                />
                <MDBCardTitle className="text-center mb-3">
                  Obstetrics and Gynaecology
                </MDBCardTitle>
                <MDBCardText style={{ color: "black" }}>
                  Obstetrics and Gynecology (OB/GYN) is the medical specialty
                  focusing on women's reproductive health, covering pregnancy,
                  childbirth, and female reproductive system disorders.
                </MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
          <MDBCol>
            <MDBCard
              className="h-100"
              style={{ background: "white", color: "black" }}
            >
              <MDBCardBody
                className="img-fluid shadow-5-strong rounded-4"
                style={{ textAlign: "center" }}
              >
                <MDBCardImage
                  src="../image/monitoring.png"
                  fluid
                  alt="..."
                  style={{
                    maxWidth: "100%",
                    display: "block",
                    margin: "10px auto",
                  }}
                />
                <MDBCardTitle className="text-center mb-3">
                  Orthopaedics
                </MDBCardTitle>
                <MDBCardText style={{ color: "black" }}>
                  Orthopaedics is the medical specialty that deals with
                  conditions related to the musculoskeletal system, encompassing
                  bones, joints, ligaments, tendons, and muscles.
                </MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
          <MDBCol>
            <MDBCard
              className="h-100"
              style={{ background: "white", color: "black" }}
            >
              <MDBCardBody
                className="img-fluid shadow-5-strong rounded-4"
                style={{ textAlign: "center" }}
              >
                <MDBCardImage
                  src="../image/medical_beds.png"
                  fluid
                  alt="..."
                  style={{
                    maxWidth: "100%",
                    display: "block",
                    margin: "10px auto",
                  }}
                />
                <MDBCardTitle className="text-center mb-3">
                  Paediatric and Child Care
                </MDBCardTitle>
                <MDBCardText style={{ color: "black" }}>
                  Pediatric and Child Care is the medical specialty dedicated to
                  the health and well-being of infants, children, and
                  adolescents, covering medical care, development, and specific
                  health issues for young individuals.
                </MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
          <MDBCol>
            <MDBCard
              className="h-100"
              style={{ background: "white", color: "black" }}
            >
              <MDBCardBody
                className="img-fluid shadow-5-strong rounded-4"
                style={{ textAlign: "center" }}
              >
                <MDBCardImage
                  src="../image/laboratory.png"
                  fluid
                  alt="..."
                  style={{
                    maxWidth: "100%",
                    display: "block",
                    margin: "10px auto",
                  }}
                />
                <MDBCardTitle className="text-center mb-3">
                  Urology
                </MDBCardTitle>
                <MDBCardText style={{ color: "black" }}>
                  Urology is the medical specialty focusing on the diagnosis and
                  treatment of conditions related to the urinary tract and male
                  reproductive system.
                </MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
          <MDBCol>
            <MDBCard
              className="h-100"
              style={{ background: "white", color: "black" }}
            >
              <MDBCardBody
                className="img-fluid shadow-5-strong rounded-4"
                style={{ textAlign: "center" }}
              >
                <MDBCardImage
                  src="../image/lab.png"
                  fluid
                  alt="..."
                  style={{
                    maxWidth: "100%",
                    display: "block",
                    margin: "10px auto",
                  }}
                />
                <MDBCardTitle className="text-center mb-3">
                  Bariatric Surgery
                </MDBCardTitle>
                <MDBCardText style={{ color: "black" }}>
                  Bariatric Surgery involves surgical procedures aimed at aiding
                  weight loss for individuals with obesity by altering the
                  digestive system.
                </MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
          <MDBCol>
            <MDBCard
              className="h-100"
              style={{ background: "white", color: "black" }}
            >
              <MDBCardBody
                className="img-fluid shadow-5-strong rounded-4"
                style={{ textAlign: "center" }}
              >
                <MDBCardImage
                  src="../image/inpatient_outpatient.png"
                  fluid
                  alt="..."
                  style={{
                    maxWidth: "100%",
                    display: "block",
                    margin: "10px auto",
                  }}
                />
                <MDBCardTitle className="text-center mb-3">
                  General Surgery
                </MDBCardTitle>
                <MDBCardText style={{ color: "black" }}>
                  General Surgery involves a wide range of surgical procedures
                  addressing various body systems, excluding those related to
                  the heart, brain, and bones.
                </MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
        </MDBRow>
        <MDBRow className="row-cols-1 row-cols-md-6 g-4">
          <MDBCol>
            <MDBCard
              className="h-100 shadow-inner"
              style={{ background: "white", color: "black" }}
            >
              <MDBCardBody
                className="img-fluid shadow-5-strong rounded-4"
                style={{ textAlign: "center" }}
              >
                <MDBCardImage
                  src="../image/Xray.png"
                  fluid
                  alt="..."
                  style={{
                    maxWidth: "100%",
                    display: "block",
                    margin: "10px auto",
                  }}
                />
                <MDBCardTitle className="text-center mb-3">
                  Hemato Oncology
                </MDBCardTitle>
                <MDBCardText style={{ color: "black" }}>
                  Hemato Oncology is the field of medicine specializing in the
                  diagnosis and treatment of blood cancers, such as leukemia and
                  lymphoma.
                </MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
          <MDBCol>
            <MDBCard
              className="h-100"
              style={{ background: "white", color: "black" }}
            >
              <MDBCardBody
                className="img-fluid shadow-5-strong rounded-4"
                style={{ textAlign: "center" }}
              >
                <MDBCardImage
                  src="../image/inpatient_outpatient.png"
                  fluid
                  alt="..."
                  style={{
                    maxWidth: "100%",
                    display: "block",
                    margin: "10px auto",
                  }}
                />
                <MDBCardTitle className="text-center mb-3">
                  Renal Scince
                </MDBCardTitle>
                <MDBCardText style={{ color: "black" }}>
                  Renal Science pertains to the study of the structure and
                  function of the kidneys, encompassing research and treatments
                  related to kidney health and diseases.
                </MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
          <MDBCol>
            <MDBCard
              className="h-100"
              style={{ background: "white", color: "black" }}
            >
              <MDBCardBody
                className="img-fluid shadow-5-strong rounded-4"
                style={{ textAlign: "center" }}
              >
                <MDBCardImage
                  src="../image/day_care.png"
                  fluid
                  alt="..."
                  style={{
                    maxWidth: "100%",
                    display: "block",
                    margin: "10px auto",
                  }}
                />
                <MDBCardTitle className="text-center mb-3">
                  Robotic Assisted Surgery
                </MDBCardTitle>
                <MDBCardText style={{ color: "black" }}>
                  Robotic Assisted Surgery involves surgical procedures
                  performed with the assistance of robotic systems to enhance
                  precision and control during operations.
                </MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
          <MDBCol>
            <MDBCard
              className="h-100"
              style={{ background: "white", color: "black" }}
            >
              <MDBCardBody
                className="img-fluid shadow-5-strong rounded-4"
                style={{ textAlign: "center" }}
              >
                <MDBCardImage
                  src="../image/emergency.png"
                  fluid
                  alt="..."
                  style={{
                    maxWidth: "100%",
                    display: "block",
                    margin: "10px auto",
                  }}
                />
                <MDBCardTitle className="text-center mb-3">
                  Nephrology
                </MDBCardTitle>
                <MDBCardText style={{ color: "black" }}>
                  Nephrology is the medical specialty focusing on the diagnosis
                  and treatment of kidney-related conditions and diseases.
                </MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
          <MDBCol>
            <MDBCard
              className="h-100"
              style={{ background: "white", color: "black" }}
            >
              <MDBCardBody
                className="img-fluid shadow-5-strong rounded-4"
                style={{ textAlign: "center" }}
              >
                <MDBCardImage
                  src="../image/monitoring.png"
                  fluid
                  alt="..."
                  style={{
                    maxWidth: "100%",
                    display: "block",
                    margin: "10px auto",
                  }}
                />
                <MDBCardTitle className="text-center mb-3">
                  Obstetrics and Gynaecology
                </MDBCardTitle>
                <MDBCardText style={{ color: "black" }}>
                  Obstetrics and Gynecology (OB/GYN) is the medical specialty
                  focusing on women's reproductive health, covering pregnancy,
                  childbirth, and female reproductive system disorders.
                </MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
          <MDBCol>
            <MDBCard
              className="h-100"
              style={{ background: "white", color: "black" }}
            >
              <MDBCardBody
                className="img-fluid shadow-5-strong rounded-4"
                style={{ textAlign: "center" }}
              >
                <MDBCardImage
                  src="../image/laboratory.png"
                  fluid
                  alt="..."
                  style={{
                    maxWidth: "100%",
                    display: "block",
                    margin: "10px auto",
                  }}
                />
                <MDBCardTitle className="text-center mb-3">
                  Orthopaedics
                </MDBCardTitle>
                <MDBCardText style={{ color: "black" }}>
                  Orthopaedics is the medical specialty that deals with
                  conditions related to the musculoskeletal system, encompassing
                  bones, joints, ligaments, tendons, and muscles.
                </MDBCardText>
              </MDBCardBody>
            </MDBCard>
          </MDBCol>
        </MDBRow>
        <div style={{ marginTop: "40px", textAlign: "center",marginBottom :"40px"}}>
          <Button variant="contained" color="success" style={{ paddingLeft:"50px", paddingRight:"50px" ,paddingTop: "10px",paddingBottom:"10px", fontSize:"19px"}}>Book Appointment</Button>
        </div>
      </Card>
      ;
    </div>
  );
}
