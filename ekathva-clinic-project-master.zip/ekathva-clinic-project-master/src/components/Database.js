import { initializeApp } from "firebase/app";
import { getFirestore } from "@firebase/firestore";

import {getAuth} from "firebase/auth";

// const firebaseConfig = {
//   apiKey: "AIzaSyC35kTl8zi8TrYWq3VcyZ81omNycPDz6Gg",
//   authDomain: "project-bf1f1.firebaseapp.com",
//   projectId: "project-bf1f1",
//   storageBucket: "project-bf1f1.appspot.com",
//   messagingSenderId: "904699056785",
//   appId: "1:904699056785:web:b0b882b72969849d09e530",
//   measurementId: "G-N2KGSC9E2Q"
// };
const firebaseConfig = {
  apiKey: "AIzaSyCZHnI_s5MyubSkNYtL9J44c4pALc6N9XE",
  authDomain: "ekathva-clinic.firebaseapp.com",
  projectId: "ekathva-clinic",
  storageBucket: "ekathva-clinic.appspot.com",
  messagingSenderId: "352858364252",
  appId: "1:352858364252:web:71889edb9c1d7aaf6cc999",
  measurementId: "G-E0CRG5D7V5"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
export const auth = getAuth(app);
export default app;

