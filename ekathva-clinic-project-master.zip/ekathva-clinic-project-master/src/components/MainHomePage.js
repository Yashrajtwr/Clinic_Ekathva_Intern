import React from 'react'
import Cards from "./Docters";
import Register from ".//Register";
import Review from "./Review";
export default function MainHomePage() {
  return (
    <div>
        <Cards/>
        <Register/>
        <Review/>    
    </div>
  )
}
