import React, { useState } from "react";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";

import Card from "react-bootstrap/Card";
import Form from "react-bootstrap/Form";
import InputGroup from "react-bootstrap/InputGroup";
import {
  CInputGroupText,
  CInputGroup,
  CFormInput,
  CFormSelect,
  CCol,
} from "@coreui/react";
export default function PatientReg() {
  const [selectedDate, setSelectedDate] = useState(new Date());
  const customStyles = {
    input: {
      width: "220px", // Adjust width as needed
      padding: "8px",
      border: "1px solid #ccc",
      borderRadius: "4px",
      fontSize: "16px",
    },
  };

  return (
    <div>
      <Card>
        <div
          style={{ textAlign: "center", marginLeft: "10%", marginRight: "10%" }}
        >
          <h1>New Patient Registration</h1>
          <h5>Please fill in the from below</h5>
        </div>

        <Card.Body>
          <div>
            <p>Registration Date and Time</p>
            <DatePicker
              selected={selectedDate}
              onChange={(date) => setSelectedDate(date)}
              showTimeSelect
              timeFormat="HH:mm"
              timeIntervals={15}
              dateFormat="MMMM d, yyyy h:mm aa"
              timeCaption="Time"
              customInput={<input style={customStyles.input} />}
            />
          </div>
          <br></br>
          <br></br>

          <p>Health Care/Card Number</p>
          <input type="number" id="numberInput" style={customStyles.input} />
          <br></br>
          <br></br>
          <p>Patient Name</p>
          <InputGroup className="mb-3">
            <InputGroup.Text>Patient First and last Name</InputGroup.Text>
            <Form.Control aria-label="First name" />
            <Form.Control aria-label="Last name" />
          </InputGroup>
          <br></br>
          <p>Patient Gnder</p>
          <CInputGroup className="mb-3">
            <CInputGroupText component="label" htmlFor="inputGroupSelect01">
              Select Gender
            </CInputGroupText>
            <CFormSelect
              id="inputGroupSelect01"
              // value={gender}
              // onChange={(event) => {
              //   setGender(event.target.value);
              // }}
            >
              <option>Choose...</option>
              <option>Male</option>
              <option>Female</option>
            </CFormSelect>
          </CInputGroup>

          <div>
            <p> Date Birth and Time(Optinal)</p>
            <DatePicker
              selected={selectedDate}
              onChange={(date) => setSelectedDate(date)}
              showTimeSelect
              timeFormat="HH:mm"
              timeIntervals={15}
              dateFormat="MMMM d, yyyy h:mm aa"
              timeCaption="Time"
              customInput={<input style={customStyles.input} />}
            />
          </div>
          <p>Phone Number</p>
          <input type="number" id="numberInput" style={customStyles.input} />
          <CCol md={6}>
            <CFormInput
              type="email"
              id="inputEmail4"
              label="Email"
              // onChange={(event) => {
              //   setEmail(event.target.value);
              // }}
            />
          </CCol>
          <br></br>
          <InputGroup className="mb-3">
            <InputGroup.Text id="inputGroup-sizing-default">
              Address(Street)
            </InputGroup.Text>
            <Form.Control
              aria-label="Default"
              aria-describedby="inputGroup-sizing-default"
            />
          </InputGroup>
          <br></br>
          <InputGroup className="mb-3">
            <InputGroup.Text id="inputGroup-sizing-default">
              Address(Street Address Line 2)
            </InputGroup.Text>
            <Form.Control
              aria-label="Default"
              aria-describedby="inputGroup-sizing-default"
            />
          </InputGroup>
          <br></br>
          <InputGroup className="mb-3">
            <InputGroup.Text id="inputGroup-sizing-default">
              City
            </InputGroup.Text>
            <Form.Control
              aria-label="Default"
              aria-describedby="inputGroup-sizing-default"
            />
          </InputGroup>
          <br></br>
          <InputGroup className="mb-3">
            <InputGroup.Text id="inputGroup-sizing-default">
              State
            </InputGroup.Text>
            <Form.Control
              aria-label="Default"
              aria-describedby="inputGroup-sizing-default"
            />
          </InputGroup>
          <br></br>
          <InputGroup className="mb-3">
            <InputGroup.Text id="inputGroup-sizing-default">
              Postal/Zip Code
            </InputGroup.Text>
            <Form.Control
              aria-label="Default"
              aria-describedby="inputGroup-sizing-default"
            />
          </InputGroup>
          <br></br>
          <p>Marital Status</p>
          <CInputGroup className="mb-3">
            <CInputGroupText component="label" htmlFor="inputGroupSelect01">
              Select Gender
            </CInputGroupText>
            <CFormSelect
              id="inputGroupSelect01"
              // value={gender}
              // onChange={(event) => {
              //   setGender(event.target.value);
              // }}
            >
              <option>Choose...</option>
              <option>Single</option>
              <option>Married</option>
              <option>Divorced</option>
              <option>Legally separated</option>
              <option>Widowed</option>
            </CFormSelect>
          </CInputGroup>
          <br></br>
          <p>Is the patient younger than 18?</p>
          <Form>
            {["radio"].map((type) => (
              <div key={`inline-${type}`} className="mb-3">
                <Form.Check
                  inline
                  label="Yes"
                  name="group1"
                  type={type}
                  id={`inline-${type}-1`}
                />
                <Form.Check
                  inline
                  label="No"
                  name="group1"
                  type={type}
                  id={`inline-${type}-2`}
                />
                
              </div>
            ))}
          </Form>
          <br></br>
          <h5>Emergency Contact</h5>
          <p>Emergency Contact</p>
          <InputGroup className="mb-3">
            <InputGroup.Text>First and Last Name</InputGroup.Text>
            <Form.Control aria-label="First name" />
            <Form.Control aria-label="Last name" />
          </InputGroup>
          <br></br>
        
          <CCol md={6}>
              <CFormInput
                type="text"
                id="inputPassword4"
                label="Relationship"
                
              />
            </CCol>
            <p>Contect Number</p>
          <input type="number" id="numberInput" style={customStyles.input} />
          <br></br>
          <br></br>
          
          <InputGroup className="mb-3">
            <InputGroup.Text>Family Doctor Name</InputGroup.Text>
            <Form.Control aria-label="First name" />
            <Form.Control aria-label="Last name" />
          </InputGroup>
          <br></br>
          <p>Family Doctor Phone Number</p>
          <input type="number" id="numberInput" style={customStyles.input} />
          
          <br></br>
          <br></br>
          <br></br>
          <h4>Health History</h4>
          <br></br>
          
          <InputGroup className="mb-3">
            <InputGroup.Text>Reason for Registration</InputGroup.Text>
            <Form.Control aria-label="First name" />
          </InputGroup>
          <br></br>
          <br></br>
          <InputGroup className="mb-3">
            <InputGroup.Text>Additional Notes</InputGroup.Text>
            <Form.Control aria-label="First name" />
          </InputGroup>

          <br></br>
          <p>Taking any medications currently?</p>
          <Form>
            {["radio"].map((type) => (
              <div key={`inline-${type}`} className="mb-3">
                <Form.Check
                  inline
                  label="Yes"
                  name="group1"
                  type={type}
                  id={`inline-${type}-1`}
                />
                <Form.Check
                  inline
                  label="No"
                  name="group1"
                  type={type}
                  id={`inline-${type}-2`}
                />
                
              </div>
            ))}
          </Form>
          <br></br>
        </Card.Body>
      </Card>
    </div>
  );
}
