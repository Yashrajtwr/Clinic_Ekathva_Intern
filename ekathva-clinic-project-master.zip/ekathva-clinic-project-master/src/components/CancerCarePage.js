import React from "react";
import { MDBCard, MDBCardImage, MDBCardBody } from "mdb-react-ui-kit";
import TreatmentProcedures  from "./TreatmentProcedures";
import CancerContent from "./CancerContent";

export default function CancerCarePage() {
  return (
    <div>
      <MDBCard >
        <MDBCardImage
          overlay
          src="../helth_image/cancer_care.png"
          alt="..."
          style={{ width: "100%" }}
        />
      </MDBCard>
      <MDBCard
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          padding: "10px",
          marginLeft: "30px",
          marginRight: "30px",
          boxShadow: "3px 3px 5px 0px rgba(0,0,0,0.1)",
        }}
      >
        <MDBCardImage
          src="../helth_image/Icon_White.png"
          style={{
            top: "10%",
            left: "10%",
            alignItems: "center",
            width: "200px",
            height: "auto",
            borderRadius: "10%",
            marginTop:"30px",
            marginBottom:"30px",
            background: "linear-gradient(to right, #4e54c8, #8f94fb)",
          }}
        ></MDBCardImage>
        <h1
         style={{ color: "#00b7ac",  marginLeft: "30px" }}>Cancer Care</h1>
        <h3
         style={{ color: "#00b7ac", marginBottom: "50px", marginLeft: "30px" }}
        >Best Cancer Hospital in Yeshwanthpur Bangalore</h3>
        <MDBCardBody style={{fontSize:"19px", textAlign: 'justify',paddingLeft:"20px",paddingRight:"20px"}}>
          Our Centre of Excellence in Oncology practises a holistic approach in
          treating the entire spectrum of cancers at all the stages. The
          department has complete spectrum of Clinical Specialties in Oncology
          including Surgical, Medical (Chemotherapy, Immunotherapy, and Hormone
          Therapy), Radiation Therapy, Hematology and bone marrow transplant.
          Our team of experts are extremely adept at diagnosing the most
          challenging cases, staging the disease, treating with medications,
          radiotherapy or operating with the advanced technology that Manipal
          Hospitals is equipped with, to combat cancers across all ages
          including children. Quaternary care is at the core of our healing
          ethos and our specialised experts are aces in this discipline.
        </MDBCardBody>
      </MDBCard>
      <div>
         <TreatmentProcedures/>
         <CancerContent/>
      </div>
    </div>
  );
}
