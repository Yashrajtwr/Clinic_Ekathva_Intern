import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "@coreui/coreui/dist/css/coreui.min.css";
import { CCard, CCardBody } from "@coreui/react";

export default function CancerContent() {
  return (
    <div>
      <CCard
        className="info"
        // style={{ boxShadow: "3px 3px 5px 0px rgba(0,0,0,0.5)" }}
      >
        <CCardBody>
          <img
            src="/helth_image/machine.png"
            align="left"
            width="40%"
            height="30%"
            class="img_left"
            alt=""
          />
          <p class = 'p1' style={{ fontSize: "20px",color: "#211f1b",
                    fontFamily: "Montserrat",
                    }}>
            What makes pinpointing the area of the cancer affliction and
            planning the best mode of treatment for patients possible are the
            modern scanning and diagnostic tools at our Centre of Excellence in
            Cancer Care. Offering both outpatient and inpatient services in
            medical and surgical oncology, hospital visits are made comfortable
            and relaxing for patients and their families during their delicate
            time. Our scope of services includes medical, radiation and surgical
            oncological services that include: Medical Oncology Medical oncology
            mostly involves various types of treatment therapies through
            medication including chemotherapy, biological therapy, bone marrow
            aspiration and transplant among others. Radiation oncology is the
            controlled use of radiation therapy to treat cancer hence it is
            non-invasive. Leveraging their advanced surgical expertise coupled
            with the gamut of high-precision medical technology, our surgical
            oncology team performs the most intricate treatment procedures.
            Their surgical prowess includes challenging robot assisted cancer
            surgeries of the esophagus, mouth, thyroid, breast, stomach,
            intestines, uterus, cervix, as well as breast reconstruction.
            Patients are at the centre of our care and whether you need to be
            admitted to our hospital or walk in for a day care cancer diagnosis
            or treatment our high precision diagnostic equipment enables our
            prolific oncology team to prescribe the best mode of cancer
            treatment under their care. Radiation Oncology Radiation oncology is
            a medical specialty that involves the controlled use of radiation to
            treat cancer. For both, those patients who come in for radiation
            treatment to bust the cancer cells and leave soon as the treatment
            is done, as well as those who require brief hospitalisation, Manipal
            Hospital offers keen outpatient and inpatient services. Surgical
            Oncology Manipal Hospital’s surgical oncology division offers
            premium outpatient and inpatient services to cancer patients.
            Whether you need to be admitted to our hospital for cancer
            screening, or come in for a day procedure like chemotherapy or
            radiation therapy to combat cancer, our high precision diagnostic
            equipment helps our cancer care team to prescribe the best mode of
            treatment.
          </p>
        </CCardBody>
      </CCard>
      <h1
        style={{ color: "#00b7ac", marginBottom: "50px", marginLeft: "30px" }}
      >
        Treatment and Procedures
      </h1>
      <CCard
        className="info"
        // style={{ boxShadow: "3px 3px 5px 0px rgba(0,0,0,0.5)" }}
      >
        <CCardBody>
          <img
            src="/helth_image/facility.png"
            align="left"
            width="40%"
            height="30%"
            class="img_left"
            style={{margin:"20px"}}
            alt=""
          />
          <p class="p1" style={{fontSize:"20px",color: "#211f1b",
                    fontFamily: "Montserrat",marginLeft:"10px"}}>
            What makes pinpointing the area of the cancer affliction and planning the best mode of treatment for patients possible are the modern scanning and diagnostic tools at our Centre of Excellence in Cancer Care. Offering both outpatient and inpatient services in medical and surgical oncology, hospital visits are made comfortable and relaxing for patients and their family during their delicate time. Our scope of services includes medical, radiation and surgical oncological services that include: MEDICAL ONCOLOGY: - Outpatient and inpatient services - Chemotherapy for malignant solid tumours and malignant blood diseases - Biological Therapy for treatment of cancer - Intra Cavitary Chemotherapy - Day care and domiciliary chemotherapy - Bone Marrow Transplant for benign and malignant diseases - Peripherally inserted central catheter insertion, bone marrow aspiration and biopsy - Central line and chemo port use - Palliative care - Child Life Care - Play therapy clinic - Counselling RADIATION ONCOLOGY: - Outpatient and inpatient services - Two Linear accelerator – Elekta Precise and Elekta Infinity along with Gamma med brachytherapy system offering complete range of radiation oncology service - Image Guided Radio Therapy (IGRT) with onboard Cone Beam CT (CBCT) - Volumetric Modulated Arc Therapy (VMAT) - Intensity Modulated Radio Therapy (IMRT) - Stereotactic Body Radio Therapy (SBRT) - Stereotactic Radio Surgery (SRS) - Flattening filter-free- faster SRS delivery (FFF) - Electrons for superficial tumors - 3 Dimensional Conformal Radio Therapy (3DCRT) - 2 Dimensional Palliative Radio Therapy - 4 Dimensional big bore CT Simulator for assessing respiratory motion of the tumor with tumor lock (4DCT) - Active Breath Hold controller for reducing tumor motion due to respiration (ABH) - 2 dimensional Varian acuity simulator - Smart arc and dynamic treatment planning - Brachyvision planning for brachytherapy - Interstitial implants – Head and neck, Gynaecological , Soft tissue sarcoma (ISBT) - Intra Cavitary Radio Therapy for cervix, common bile duct tumors, etc (ICR) - Image-guided brachytherapy SURGICAL ONCOLOGY: - Outpatient and inpatient services - Robotic assisted cancer surgery - Radio guided cancer surgery – - SLNB – Sentinal Lymph Node Biopsy - MIRP – Minimal Invasive Radio-guided Parathyroid Surgery - ROLL – Radio-guided Occult Lesion Localisation for CA breast - Early Detection of Breast Cancers - Breast Reconstruction - Breast Conservative Surgery - Vascular access – PORT –A – CATH - Voice Prosthesis Surgery for CA Larynx - Intra Peritoneal (IP) chemotherapy port - HIPEC- Hypertheic Intra Peritonal Chemotherapy - CRS- Major Peritonectomy Cytoreductive Surgery - Microvascular Reconstruction - Breast Oncoplasty Procedures - Musculo Skeletal and Ortho Oncology - Colposcopy clinic - Robotic Surgery for Gynaecological cases – Uterus and Cervix - Robotic GI cancer surgeries - Robotic Oesophageal cancer surgeries - Scarless Robotic Thyroidectomy - Trans Oral Robotic Surgery - Robotic surgery for lung and Mediastinum and Chest Tumours - Multi- disciplinary Tumour Board
          </p>
        </CCardBody>
      </CCard>
    </div>
  );
}
