import React from "react";

import {
  CCard,
  CCardBody,
  CCardTitle,
  CInputGroupText,
  CInputGroup,
  CFormInput,
  CFormSelect,
  CCol,
  CForm,
  CFormTextarea,
  CButton,
} from "@coreui/react";
import {db} from "./Database";
import { useState } from "react";
import { collection } from "firebase/firestore";
import { addDoc } from "firebase/firestore";
import { toast } from 'react-toastify';
import { auth } from "./Database";
import {
  createUserWithEmailAndPassword
} from "firebase/auth";

const LogInPage = () => {
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [middleName, setMiddleName] = useState("");
  const [gender, setGender] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [conformPassword, setConformPassword] = useState("");
  const [discription, setDiscription] = useState("");
  const database_ob = collection(db, "SignUpNew");
  
  
const regiter = async() =>{
    
    await createUserWithEmailAndPassword(auth,email,password);
    
    toast.success("The regiter success");
    
}
  const insert = async () => {
    
    if(firstName !== ""){
      if(middleName !== ""){
        if(lastName !== ""){
          if(gender !== ""){
            if(email !== ""){
              if(password !== ""){
              
                if(password === conformPassword){
                  
                  await addDoc(database_ob, {
                    first_name: firstName,
                    last_name: lastName,
                    middle_name: middleName,
                    gender: gender,
                    email: email,
                    password: password,
                    conform: conformPassword,
                    discription: discription
                  });
                  
                  toast.success("The data Added Successfully....!");
                  regiter();
                }else{
                  toast.info("Enter the password is not equall to the conform password");
                }
              }else{
                toast.info("Enter the password.");
              }
            }else{
              toast.info("Enter the email.");
            }
          }else{
            toast.info("select the gender.");
          }
        }else{
          toast.info("Enter the last name.");
        }

      }else{
        toast.info("Enter the middle name.");
      }
    }else{
      toast.info("Enter the first name.");
    }
  };

  return (
    <div>
      <CCard className="info">
        <CCardBody>
          <CCardTitle>Sign Up</CCardTitle>
          <br></br>
          <br></br>
          <CInputGroup>
            <CInputGroupText>First and Middle and Last name</CInputGroupText>

            <CFormInput
              aria-label="First Name"
              onChange={(event) => {
                setFirstName(event.target.value);
              }}
            />
            <CFormInput
              aria-label="Middle Name"
              onChange={(event) => {
                setMiddleName(event.target.value);
              }}
            />
            <CFormInput
              aria-label="Last Name"
              onChange={(event) => {
                setLastName(event.target.value);
              }}
            />
          </CInputGroup>
          <br></br>
          <CInputGroup className="mb-3">
            <CInputGroupText component="label" htmlFor="inputGroupSelect01">
              Select Gender
            </CInputGroupText>
            <CFormSelect
              id="inputGroupSelect01"
              value={gender}
              onChange={(event) => {
                setGender(event.target.value);
              }}
            >
              <option>Choose...</option>
              <option>Male</option>
              <option>Female</option>
            </CFormSelect>
          </CInputGroup>
          <CForm className="row g-3">
            <CCol md={6}>
              <CFormInput
                type="email"
                id="inputEmail4"
                label="Email"
                onChange={(event) => {
                  setEmail(event.target.value);
                }}
              />
            </CCol>
            <CCol md={6}>
              <CFormInput
                type="password"
                id="inputPassword4"
                label="Password"
                onChange={(event) => {
                  setPassword(event.target.value);
                }}
              />
            </CCol>
          </CForm>
          <CCol md={6}>
            <CFormInput
              type="password"
              id="inputPassword4"
              label="Confirn Password"
              onChange={(event) => {
                setConformPassword(event.target.value);
              }}
            />
          </CCol>
          <CForm>
            <CFormTextarea
              id="exampleFormControlTextarea1"
              label="description"
              rows="3"
              text="Must be 8-20 words long."
              onChange={(event) => {
                setDiscription(event.target.value);
              }}
            ></CFormTextarea>
          </CForm>
          <CButton onClick={insert}>Enter</CButton>
       
        </CCardBody>
      </CCard>
    </div>
  );
};

export default LogInPage;
