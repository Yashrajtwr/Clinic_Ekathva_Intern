import React from "react";

import ShortStory from "./ShortStory";

function HomePage() {
  return (
    <div>
      {/* <Specialities /> */}
      <ShortStory />
    </div>
  );
}

export default HomePage;
