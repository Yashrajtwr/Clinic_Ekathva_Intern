import React from "react";
import { Link, useNavigate } from "react-router-dom";
import GoogleButton from "react-google-button";
import { useState } from "react";
import { auth } from "./Database";
import {
  signInWithEmailAndPassword,
  GoogleAuthProvider,
  signInWithPopup,
} from "firebase/auth";
import {
  CCard,
  CCardBody,
  CCardTitle,
  CFormInput,
  CForm,
  CButton,
  CCardHeader,
  CCardText,
} from "@coreui/react";
import { toast } from "react-toastify";

function LogInPage() {
  const navigate = useNavigate();

  const [patientNewEmail, setPatientNewEmail] = useState("");
  const [patientNewPassword, setPatientNewPassword] = useState("");

  const PatientLogIn = async () => {
    try{
        await signInWithEmailAndPassword(
        auth,
        patientNewEmail,
        patientNewPassword
      ); 
      toast.success(" Patient Log In success ");
      navigate("/PatientMainPage");
    }catch(err){
      toast.error(err);
    }
  };


  const logInWithGoogle = async (e) => {
    e.preventDefault();
    try {
      const googleAuthProvider = new GoogleAuthProvider();
      await signInWithPopup(auth, googleAuthProvider);
      toast.success(" Log In Success");
      navigate("/PatientMainPage");
    } catch (err) {
      toast.error(err);
    }
  };

  return (
    <div>
      <>
        <CCard className="info">
        <CCardHeader>Patient Log In</CCardHeader>
          <CCardBody>
            <CCardTitle>LogIn</CCardTitle>
            <CCardText>
              
            </CCardText>

            <CForm>
              <CFormInput
                type="email"
                id="exampleFormControlInput1"
                label="Email address"
                placeholder="name@example.com"
                aria-describedby="exampleFormControlInputHelpInline"
                onChange={(event) => {
                  setPatientNewEmail(event.target.value);
                }}
              />
            </CForm>

            <CForm>
              <CFormInput
                type="password"
                id="exampleFormControlInput1"
                label="Enter the password"
                text="Must be 8-20 characters long."
                aria-describedby="exampleFormControlInputHelpInline"
                onChange={(event) => {
                  setPatientNewPassword(event.target.value);
                }}
              />
            </CForm>
            
            <CButton onClick={PatientLogIn}>LOG IN</CButton><br></br>
            <p>if you don't have an account click here <Link to="/SignUpPage">Sign Up</Link></p> 
            
            <br></br>
            <GoogleButton onClick={logInWithGoogle}></GoogleButton>
            
            
          </CCardBody>
        </CCard>
      </>
    </div>
  );
}

export default LogInPage;
