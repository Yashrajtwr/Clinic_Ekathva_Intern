import React from 'react';

export default function AdminPage() {
  return (
    <div>
        <h1>hellow</h1>
    </div>
  )
}
