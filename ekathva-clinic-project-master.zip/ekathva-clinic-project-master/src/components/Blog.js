import React from "react";
import Card from "react-bootstrap/Card";
import Carousel from "react-multi-carousel";
import Button from "react-bootstrap/Button";
import { Link } from "react-router-dom";

const responsive = {
  superLargeDesktop: {
    breakpoint: { max: 4000, min: 3000 },
    items: 5,
  },
  desktop: {
    breakpoint: { max: 3000, min: 1024 },
    items: 3,
  },
  tablet: {
    breakpoint: { max: 1024, min: 464 },
    items: 2,
  },
  mobile: {
    breakpoint: { max: 464, min: 0 },
    items: 1,
  },
};

const cardData = [
  // ... (your card data)
  {
    img_src: "../helth_image/plastic.png",
    text: "Preparing for Plastic Surgery",
    title:
      "Embarking on a journey towards plastic surgery requires careful planning and preparation. Undergoing plastic surgery is a significant decision that can bring about positive changes in one's life.and postive ",
    link: "./PlasticSer",
  },
  {
    img_src: "../helth_image/Plastic2.png",
    text: "Understanding the Risks and Benefits of Plastic Surgery",
    title:
      "Plastic surgery has gained immense popularity in recent years, offering individuals the opportunity to enhance their appearance and improve their self-esteem. Whether it's a nose job, breast ",
    link: "./PlasticSer",
  },
  {
    img_src: "../helth_image/pl3.png",
    text: "Top Dental Health Tips for a Stunning Smile",
    title:
      "A stunning smile is not just about aesthetics; it reflects your overall health and well-being. Maintaining good dental health and oral hygiene practices is essential for achieving that radiant smile and  ",
    link: "./DentalHealth",
  },
  {
    img_src: "../helth_image/pl4.png",
    text: "Bladder Sparing Surgeries",
    title:
      "In the realm of medical advancements, bladder-sparing surgeries have emerged as a groundbreaking approach for treating bladder cancers. Traditional treatment options often involve complete removal of the.",
    link: "./PlasticSer",
  },
  {
    img_src: "../helth_image/pl5.png",
    text: "Newer Treatments of Allergy - Immunotherapy and Biologics",
    title:
      "In recent years, there has been a significant increase in the occurrence of allergies worldwide, impacting millions of people. Traditionally, allergy management consists of antihistamines  ",
    link: "./PlasticSer",
  },
  {
    img_src: "../helth_image/pl6.png",
    text: "Preventive Tips for Healthy Heart",
    title:
      "A healthy heart is essential for a long and vibrant life. Heart disease remains a leading cause of mortality worldwide, making it crucial to adopt preventive measures to protect our cardiovascular health. ",
    link: "./PlasticSer",
  },
  {
    img_src: "../helth_image/pl8.png",
    text: "Goitre and Other Thyroid Swellings",
    title:
      "Thyroid swellings, including goitre, are common medical conditions affecting the thyroid gland, which is located in the neck. These swellings, also known as a swollen thyroid gland, can result from various. ",
    link: "./PlasticSer",
  },
  {
    img_src: "../helth_image/pl7.png",
    text: "Preventive Tips for Healthy Heart",
    title:
      "A healthy heart is essential for a long and vibrant life. Heart disease remains a leading cause of mortality worldwide, making it crucial to adopt preventive measures to protect our cardiovascular health. ",
    link: "./PlasticSer",
  },
  {
    img_src: "../helth_image/pl3.png",
    text: "Oral hygiene",
    title:"Oral hygiene is a crucial aspect of overall health and well-beingthat often goes underestimated. Neglecting oral health can lead to arange of dental problems and even impact your systemic health.also",
    link: "./OralHygiene",
  },
];
const cardStyle = {
  width: "100%", // Set a fixed width for all cards
  marginBottom: "20px", // Adjust margin between cards
};
const Blog = () => {
  return (
    <div>
      <h1
        style={{
          color: "#00b7ac",
          marginBottom: "50px",
          marginLeft: "30px",
          marginTop: "40px",
        }}
      >
        Ekathva Clinic Blogs
      </h1>
      <div className="card-carousel">
        <Carousel
          responsive={responsive}
          autoPlay={true}
          infinite={true}
          showDots={false}
          containerClass="carousel-container"
          itemClass="carousel-item-padding"
        >
          {cardData.map((card, index) => (
            <div key={index} style={cardStyle}>
              <Card border="light" style={{ padding: "10px" }}>
                <Card.Img variant="top" src={card.img_src} fluid />
                <Card.Body>
                
                  
                  <Card.Text style={{ fontSize: "19px", color: "#211f1b", fontFamily: "Montserrat" }}>{card.text}</Card.Text>
                  <Card.Title style={{ fontSize: "20px", color: "#211f1b", fontFamily: "Montserrat" }}>
                    {card.title}
                  </Card.Title>
                  <Button variant="primary" as={Link} to={card.link}>
                    Know More
                  </Button>
                </Card.Body>
              </Card>
            </div>
          ))}
        </Carousel>
      </div>
    </div>
  );
};

export default Blog;