import { toast } from "react-toastify";
import { db } from "./Database";
import React from "react";
import { useState } from "react";
import { collection } from "firebase/firestore";
import { addDoc } from "firebase/firestore";
export default function AddDocter() {
  
  const [docterName, setDocterName] = useState("");
  const [department, setDepartment] = useState("");
  const [gender, setGender] = useState("");
  const [email, setEmail] = useState("");
  const [mobileNumber, setMobileNumber] = useState("");

  const docterCollection = collection(db, "docterInfo");


  const DocterInfoAdd = async () => {
    if (docterName !== "") {
      if (department !== "") {
        if (gender !== "") {
          if (email !== "") {
            if (mobileNumber !== "") {
              await addDoc(docterCollection, {
                name: docterName,
                docterDepartment: department,
                docterGender: gender,
                docterEmail: email,
                docterMobileNumber: mobileNumber,
              });
              toast.success("The data Added Successfully....!");
            } else {
              toast("Enter the docter mobile number");
            }
          } else {
            toast.info("Enter the docter email");
          }
        } else {
          toast.info("Select the gender");
        }
      } else {
        toast.info("Select the department ");
      }
    } else {
      toast.info("Enter the docter name");
    }
  };

  return (
    <div>
      <div class="card info">
        <div class="card-header">Add Docter</div>
        <div class="card-body">
          <blockquote class="blockquote mb-0">
            <div class="input-group">
              <span class="input-group-text">Docter Name</span>
              <input
                type="text"
                aria-label="First name"
                class="form-control"
                onChange={(event) => {
                  setDocterName(event.target.value);
                }}
              />
            </div>
            <br></br>
            <div class="input-group mb-3">
              <label class="input-group-text" for="inputGroupSelect01">
                Department
              </label>
              <select
                value={department}
                class="form-select"
                id="inputGroupSelect01"
                onChange={(event) => {
                  setDepartment(event.target.value);
                }}
              >
                <option selected>Choose...</option>
                <option>One</option>
                <option>Two</option>
                <option>Three</option>
              </select>
            </div>

            

            <div class="input-group mb-3">
              <label class="input-group-text" for="inputGroupSelect01">
                Gender
              </label>
              <select
                value={gender}
                class="form-select"
                id="inputGroupSelect01"
                onChange={(event) => {
                  setGender(event.target.value);
                }}
              >
                <option selected>Choose...</option>

                <option>Male</option>
                <option>Female</option>
              </select>
            </div>

            <div class="input-group flex-nowrap">
              <span class="input-group-text" id="addon-wrapping">
                Email
              </span>
              <input
                type="email"
                class="form-control"
                placeholder="Email"
                onChange={(event) => {
                  setEmail(event.target.value);
                }}
              />
            </div>
            <br></br>
            <div class="input-group flex-nowrap">
              <span class="input-group-text" id="addon-wrapping">
                Mobile Number
              </span>
              <input
                type="number"
                class="form-control"
                placeholder="Mobile Number"
                onChange={(event) => {
                  setMobileNumber(event.target.value);
                }}
              />
            </div>
            <div className="info">
              <button
                type="button"
                class="btn btn-primary"
                onClick={DocterInfoAdd}
              >
                Submit
              </button>
              
            </div>
          </blockquote>
        </div>
      </div>
    </div>
  );
}
