import React from "react";
import { MDBCard, MDBCardImage } from "mdb-react-ui-kit";
import Card from "react-bootstrap/Card";

export default function PlasticSer() {
  return (
    <div>
      <MDBCard>
        <MDBCardImage
          overlay
          src="../helth_image/cancer_care.png"
          alt="..."
          style={{ width: "100%" }}
        />
      </MDBCard>
      <Card>
        <Card.Body className="text-center">
          <h1>Preparing for Plastic Surgery: Making it as Easy as Possible</h1>
          <MDBCardImage src="../helth_image/plastic.png"></MDBCardImage>
          <p
            style={{
              fontSize: "20px",
              color: "#211f1b",
              fontFamily: "Montserrat",
              marginLeft: "10%",
              marginRight: "10%",
              textAlign: "justify",
            }}
          >
            Embarking on a journey towards plastic surgery requires careful
            planning and preparation. Undergoing plastic surgery is a
            significant decision that can bring about positive changes in one's
            life. Whether it's for cosmetic enhancements or reconstructive
            purposes, thorough preparation is essential for a successful and
            smooth surgical experience. This blog aims to guide you through the
            steps to make the process as easy and stress-free as possible.
            <h2>Types of Plastic Surgery Treatments</h2>
            <p1>Here are some types of Plastic Surgery treatments</p1>
            <h3 style={{ marginTop: "10px", marginBottom: "10px" }}>
              Facial Procedures:{" "}
            </h3>{" "}
            Facelift: Helps to address sagging skin, wrinkles, and other signs
            of aging. Eyelid Surgery (Blepharoplasty): Focuses on rejuvenating
            the eyelids for a more youthful look. Rhinoplasty: Aims to reshape
            the nose for both aesthetic and functional purposes.
            <h3 style={{ marginTop: "10px", marginBottom: "10px" }}>
              {" "}
              Body Contouring:
            </h3>
            Liposuction: Removes excess fat from specific areas, improving body
            proportions. Tummy Tuck (Abdominoplasty): Tightens abdominal muscles
            and removes excess skin for a firmer midsection. Breast
            Augmentation/Reduction: Enhances or reduces breast size to achieve
            desired proportions.
            <h3 style={{ marginTop: "10px", marginBottom: "10px" }}>
              {" "}
              Breast Reconstruction:
            </h3>
            Following mastectomy, breast reconstruction can restore a sense of
            normalcy and confidence for breast cancer survivors.
            <h3 style={{ marginTop: "10px", marginBottom: "10px" }}>
              {" "}
              Non-Surgical Procedures:{" "}
            </h3>
            Botox and Dermal Fillers: Minimally invasive treatments to reduce
            wrinkles and add volume to the face. Chemical Peels and
            Microdermabrasion: Improve skin texture and reduce imperfections.
          </p>

          <h1>Steps to Prepare for Plastic Surgery</h1>
          <p
            style={{
              fontSize: "20px",
              color: "#211f1b",
              fontFamily: "Montserrat",
            
              marginLeft: "10%",
              marginRight: "10%",
              textAlign: "justify",
            }}
          >
            <h3 style={{ marginTop: "10px", marginBottom: "10px" }}>
              Regular Health Checkups:{" "}
            </h3>
            <p>
              Here are essential steps to prepare for plastic surgery, making
              the process as easy and seamless as possible:
            </p>
            <h3 style={{ marginTop: "10px", marginBottom: "10px" }}>
              {" "}
              Consultation and Goal Setting:{" "}
            </h3>
            Schedule a consultation with a board-certified plastic surgeon.
            Discuss your goals, concerns, and expectations for the procedure. A
            skilled surgeon will provide honest feedback and help set realistic
            expectations.
            <h3 style={{ marginTop: "10px", marginBottom: "10px" }}>
              {" "}
              Medical Evaluation and Pre-Operative Planning:{" "}
            </h3>
            Your surgeon will conduct a thorough medical evaluation to ensure
            you're a suitable candidate for the procedure. They will provide
            pre-operative instructions, including any necessary dietary or
            medication adjustments.
            <h3 style={{ marginTop: "10px", marginBottom: "10px" }}>
              Create a Comfortable Recovery Space:{" "}
            </h3>
            Prepare your home for post-operative care. Stock up on essentials,
            arrange a comfortable resting area, and have necessary supplies like
            wound dressings and medications readily available.
            <h3 style={{ marginTop: "10px", marginBottom: "10px" }}>
              Maintain a Healthy Lifestyle:{" "}
            </h3>
            Leading up to the surgery, focus on maintaining a healthy lifestyle.
            Eating a balanced diet, staying hydrated, and engaging in light
            exercise can help optimize your body's ability to heal. Avoiding
            excessive alcohol and tobacco is also crucial for a smooth recovery.
            <h3 style={{ marginTop: "10px", marginBottom: "10px" }}>
              Assemble a Post-Surgery Care Kit:{" "}
            </h3>
            Gather supplies that will aid in your post-surgery care. This may
            include wound care supplies, pain medications (as prescribed),
            comfortable clothing, and any recommended compression garments.
            Having these items readily available will make your recovery more
            comfortable and convenient.
            <h3 style={{ marginTop: "10px", marginBottom: "10px" }}>
              Follow Pre-Surgery Guidelines:{" "}
            </h3>
            Adhere to all pre-surgery instructions provided by your surgeon.
            This may include fasting, avoiding certain medications, and
            refraining from smoking.
          </p>
          <h1>Anticipated Outcomes</h1>
          <p>
            The outcome of plastic surgery can vary depending on the procedure
            and individual factors. However, with proper preparation and a
            skilled surgeon, you can anticipate:
          </p>
          <p
            style={{
              fontSize: "20px",
              color: "#211f1b",
              fontFamily: "Montserrat",
              marginLeft: "10%",
              marginRight: "10%",
              textAlign: "justify",
            }}
          >
            <h3 style={{ marginTop: "10px", marginBottom: "10px" }}>
              Improved Aesthetics:{" "}
            </h3>
            Plastic surgery can enhance your physical appearance, leading to
            increased confidence and a more positive self-image.
            <h3 style={{ marginTop: "10px", marginBottom: "10px" }}>
              Enhanced Quality of Life:{" "}
            </h3>
            Procedures that address physical discomfort or improve functionality
            (e.g., breast reduction, rhinoplasty) can significantly enhance your
            overall quality of life.
            <h3 style={{ marginTop: "10px", marginBottom: "10px" }}>
              Long-lasting Results:{" "}
            </h3>
            While some procedures may require maintenance, the results of
            plastic surgery are generally long-lasting, providing enduring
            benefits.
          </p>
          <h2>Conclusion:</h2>
          <p
            style={{
              fontSize: "20px",
              color: "#211f1b",
              fontFamily: "Montserrat",
              marginLeft: "10%",
              marginRight: "10%",
              textAlign: "justify",
            }}
          >
            Preparing for plastic surgery involves careful planning, open
            communication with your surgeon, and a commitment to follow
            pre-operative guidelines. The benefits extend beyond physical
            appearance, encompassing improved confidence, enhanced physical
            health, and a renewed outlook on life. By approaching the process
            with diligence and with realistic expectations, you can achieve
            optimal results and embark on a journey toward greater
            self-assurance and well-being at Sakra World Hospital, a renowned
            center for plastic surgery in India.
          </p>
        </Card.Body>
      </Card>
    </div>
  );
}
