import React from "react";
import { MDBCard, MDBCardImage } from "mdb-react-ui-kit";
import Card from "react-bootstrap/Card";

export default function OralHygiene() {
  return (
    <div>
      <MDBCard>
        <MDBCardImage
          overlay
          src="../helth_image/cancer_care.png"
          alt="..."
          style={{ width: "100%" }}
        />
      </MDBCard>
      <Card>
        <Card.Body className="text-center">
          <h1>Importance of Oral Hygiene: A Comprehensive Overview</h1>
          <MDBCardImage
            src="../helth_image/Oral_Hygiene.png"
            style={{ width: "30%" }}
          ></MDBCardImage>
          <p
            style={{
              fontSize: "20px",
              color: "#211f1b",
              fontFamily: "Montserrat",
              marginLeft: "10%",
              marginRight: "10%",
              textAlign: "justify",
            }}
          >
            Oral hygiene is a crucial aspect of overall health and well-being
            that often goes underestimated. Neglecting oral health can lead to a
            range of dental problems and even impact your systemic health. In
            this comprehensive overview, we will explore the significance of
            oral hygiene, its connection to various health issues, and effective
            practices to maintain a healthy mouth.
            <h2>The Basics of Oral Hygiene</h2>
            <p1>
              Oral hygiene refers to the practice of maintaining the cleanliness
              of your mouth, teeth, and gums. This includes daily routines such
              as brushing, flossing, and using mouthwash, along with regular
              dental check-ups and cleanings. Proper oral hygiene helps prevent
              various dental issues, such as cavities, gum disease, and bad
              breath.
            </p1>
            <h2>The Relationship Between Oral and Overall Health</h2>
            <h3 style={{ marginTop: "10px", marginBottom: "10px" }}>
              Cardiovascular Health:{" "}
            </h3>{" "}
            Recent research has shown a strong link between oral health and
            cardiovascular health. Poor oral hygiene can lead to gum disease,
            which, in turn, can increase the risk of heart disease and stroke.
            Bacteria from the mouth can enter the bloodstream and cause
            inflammation in the arteries, contributing to atherosclerosis.
            <h3 style={{ marginTop: "10px", marginBottom: "10px" }}>
              {" "}
              Respiratory Health:
            </h3>
            Neglecting oral hygiene can also impact respiratory health. Bacteria
            from the mouth can be aspirated into the lungs, potentially leading
            to respiratory infections like pneumonia.
            <h3 style={{ marginTop: "10px", marginBottom: "10px" }}>
              {" "}
              Diabetes Management:
            </h3>
            Individuals with diabetes are more susceptible to gum disease, and
            gum disease can make it harder to control blood sugar levels.
            Managing oral hygiene is crucial for those with diabetes to prevent
            complications.
            <h3 style={{ marginTop: "10px", marginBottom: "10px" }}>
              {" "}
              Pregnancy Complications:{" "}
            </h3>
            Poor oral hygiene has been linked to an increased risk of preterm
            birth and low birth weight in pregnant women. Hormonal changes
            during pregnancy can make gums more susceptible to inflammation and
            infection.
          </p>

          <h1>Common Dental Issues Associated with MO h Poor Oral Hygiene</h1>
          <p
            style={{
              fontSize: "20px",
              color: "#211f1b",
              fontFamily: "Montserrat",
              marginLeft: "10%",
              marginRight: "10%",
              textAlign: "justify",
            }}
          >
            <h3 style={{ marginTop: "10px", marginBottom: "10px" }}>
              Cavities (Dental Caries):{" "}
            </h3>
            <p>
              The accumulation of plaque, a sticky film of bacteria, on teeth
              can lead to cavities. These can cause pain, discomfort, and
              eventually, tooth loss if left untreated.
            </p>
            <h3 style={{ marginTop: "10px", marginBottom: "10px" }}>
              {" "}
              Gum Disease (Periodontal Disease):{" "}
            </h3>
            Gum disease ranges from gingivitis (mild inflammation) to
            periodontitis (severe gum and bone damage). It can result in tooth
            loss and has been linked to systemic health issues.
            <h3 style={{ marginTop: "10px", marginBottom: "10px" }}>
              {" "}
              Bad Breath (Halitosis):{" "}
            </h3>
            Bacteria in the mouth produce foul-smelling compounds when they
            break down food particles. Chronic bad breath can be a social and
            personal concern.
            <h3 style={{ marginTop: "10px", marginBottom: "10px" }}>
              Tooth Sensitivity:{" "}
            </h3>
            Poor oral hygiene can lead to enamel erosion and tooth sensitivity,
            causing discomfort when consuming hot, cold, or sweet foods and
            drinks.
          </p>
          <h1>Importance of Oral Hygiene</h1>
          <p
            style={{
              fontSize: "20px",
              color: "#211f1b",
              fontFamily: "Montserrat",
              marginLeft: "10%",
              marginRight: "10%",
              textAlign: "justify",
            }}
          >
            The importance of oral hygiene cannot be overstated, as it plays a
            significant role in both your oral health and overall well-being.
            Here are some key reasons why oral hygiene is crucial:
          </p>
          <p
            style={{
              fontSize: "20px",
              color: "#211f1b",
              fontFamily: "Montserrat",
              marginLeft: "10%",
              marginRight: "10%",
              textAlign: "justify",
            }}
          >
            <h3 style={{ marginTop: "10px", marginBottom: "10px" }}>
              Preventing Dental Issues:{" "}
            </h3>
            Regular oral hygiene practices, such as brushing and flossing, help
            remove food particles and plaque from your teeth, preventing tooth
            decay, cavities, and gum disease.
            <h3 style={{ marginTop: "10px", marginBottom: "10px" }}>
              Maintaining Fresh Breath:{" "}
            </h3>
            Proper oral hygiene helps control bad breath (halitosis) by
            eliminating the bacteria that cause odors in your mouth.
            <h3 style={{ marginTop: "10px", marginBottom: "10px" }}>
              Preserving Your Smile:{" "}
            </h3>
            Good oral hygiene practices help keep your teeth clean and free of
            stains, preserving the aesthetics of your smile.
            <h3 style={{ marginTop: "10px", marginBottom: "10px" }}>
              Supporting Digestive Health:{" "}
            </h3>
            Chewing is the first step in the digestive process. Properly
            maintained teeth aid in effective chewing, which can lead to better
            digestion.
            <h3 style={{ marginTop: "10px", marginBottom: "10px" }}>
              Preventing Systemic Health Issues:{" "}
            </h3>
            There is growing evidence of a connection between oral health and
            systemic conditions such as heart disease, diabetes, respiratory
            infections, and complications during pregnancy. Good oral hygiene
            can reduce the risk of these health problems
          </p>
          <h1>Effective Oral Hygiene Practices</h1>
          <p
            style={{
              fontSize: "20px",
              color: "#211f1b",
              fontFamily: "Montserrat",
              marginLeft: "10%",
              marginRight: "10%",
              textAlign: "justify",
            }}
          >
            <h3 style={{ marginTop: "10px", marginBottom: "10px" }}>
              Brushing{" "}
            </h3>
            Brush your teeth at least twice a day using fluoride toothpaste. Use
            a soft-bristle toothbrush and brush for at least two minutes,
            covering all tooth surfaces.
            <h3 style={{ marginTop: "10px", marginBottom: "10px" }}>
              Flossing{" "}
            </h3>
            Flossing removes food particles and plaque from between teeth and
            along the gumline. It should be done at least once a day.
            <h3 style={{ marginTop: "10px", marginBottom: "10px" }}>
              Mouthwash{" "}
            </h3>
            Rinse with an antimicrobial or fluoride mouthwash to reduce bacteria
            and strengthen teeth. Follow the product's instructions.
            <h3 style={{ marginTop: "10px", marginBottom: "10px" }}>
              Regular Dental Check-ups:{" "}
            </h3>
            Visit your dentist for regular check-ups and cleanings. They can
            detect and treat dental issues early, preventing them from
            worsening.
            <h3 style={{ marginTop: "10px", marginBottom: "10px" }}>
              Healthy Diet:{" "}
            </h3>{" "}
            Consume a balanced diet rich in fruits, vegetables, and dairy
            products. Limit sugary and acidic foods and drinks, as they
            contribute to tooth decay.
            <h3 style={{ marginTop: "10px", marginBottom: "10px" }}>
              Tobacco and Alcohol:{" "}
            </h3>
            Avoid or limit tobacco and alcohol consumption, as they increase the
            risk of gum disease, oral cancers, and staining of teeth.
          </p>
          <h2>Conclusion:</h2>
          <p
            style={{
              fontSize: "20px",
              color: "#211f1b",
              fontFamily: "Montserrat",
              marginLeft: "10%",
              marginRight: "10%",
              textAlign: "justify",
            }}
          >
            Oral hygiene is not just about having a bright smile; it's crucial
            for your overall health. Neglecting oral health can lead to various
            dental problems and contribute to systemic health issues. By
            adopting effective oral health and hygiene practices, including
            regular dental check-ups at Sakra World Hospital, we can maintain a
            healthy mouth and reduce the risk of associated health problems.
            Taking care of your oral health is an investment in your overall
            well-being that should not be underestimated.
          </p>
        </Card.Body>
      </Card>
    </div>
  );
}
