import React from "react";
import { MDBCard, MDBCardImage } from "mdb-react-ui-kit";
import Card from "react-bootstrap/Card";

export default function HealthyHeart() {
  return (
    <div>
      <MDBCard>
        <MDBCardImage
          overlay
          src="../helth_image/cancer_care.png"
          alt="..."
          style={{ width: "100%" }}
        />
      </MDBCard>
      <Card>
        <Card.Body className="text-center">
          <h1>Preventive Tips for Healthy Heart</h1>
          <MDBCardImage src="../helth_image/pl7.png"></MDBCardImage>
          <p
            style={{
              fontSize: "20px",
              color: "#211f1b",
              fontFamily: "Montserrat",
              marginLeft: "10%",
              marginRight: "10%",
              textAlign: "justify",
            }}
          >
            A healthy heart is essential for a long and vibrant life. Heart
            disease remains a leading cause of mortality worldwide, making it
            crucial to adopt preventive measures to protect our cardiovascular
            health. Fortunately, many heart conditions are preventable through
            lifestyle changes and proactive habits. Here are eight preventive
            tips for a healthy heart:
            <h3 style={{ marginTop: "10px", marginBottom: "10px" }}>
              Balanced Diet:{" "}
            </h3>{" "}
            A heart-healthy diet plays a pivotal role in preventing
            cardiovascular diseases. Emphasize a balanced and diverse diet rich
            in fruits, vegetables, whole grains, lean proteins, and healthy
            fats. Minimize the intake of processed foods, sugary snacks, and
            excessive salt. Opt for foods high in omega-3 fatty acids, such as
            fatty fish (salmon, mackerel) and flaxseeds, which can lower
            cholesterol levels and reduce the risk of heart disease.
            <h3 style={{ marginTop: "10px", marginBottom: "10px" }}>
              {" "}
              Regular Physical Activity: Incorporating regular
            </h3>
            physical activity into your daily routine is one of the best ways to
            maintain heart health. Aim for at least 150 minutes of
            moderate-intensity aerobic exercise or 75 minutes of vigorous
            exercise per week. Activities like brisk walking, swimming, cycling,
            and dancing can improve cardiovascular fitness, lower blood
            pressure, and reduce the risk of heart disease.
            <h3 style={{ marginTop: "10px", marginBottom: "10px" }}>
              {" "}
              Quit Smoking:
            </h3>
            Smoking is a significant risk factor for heart disease and other
            serious health conditions. It damages blood vessels, increases blood
            pressure, and reduces the oxygen-carrying capacity of the blood. If
            you smoke, seek help from a healthcare professional to quit this
            harmful habit. Quitting smoking can significantly improve heart
            health and overall well-being.
            <h3 style={{ marginTop: "10px", marginBottom: "10px" }}>
              {" "}
              Manage Stress:{" "}
            </h3>
            Chronic stress can take a toll on your heart health. Practice
            stress-reduction techniques like meditation, deep breathing
            exercises, yoga, or spending time in nature. Engaging in hobbies and
            maintaining a work-life balance can also be beneficial. By managing
            stress, you can lower the risk of heart disease and improve your
            overall quality of life. Maintain a Healthy Weight: Excess body
            weight puts additional strain on the heart and increases the risk of
            developing heart disease. Achieve and maintain a healthy weight
            through a combination of a balanced diet and regular physical
            activity. Focus on losing weight gradually and avoid crash diets, as
            rapid weight loss can be detrimental to heart health. Control Blood
            Pressure and Cholesterol:
            <h3 style={{ marginTop: "10px", marginBottom: "10px" }}>
              {" "}
              Control Blood Pressure and Cholesterol:{" "}
            </h3>
            High blood pressure and elevated cholesterol levels are significant
            risk factors for heart disease. Regularly monitor your blood
            pressure and cholesterol levels, and follow your healthcare
            provider's advice on managing them. Lifestyle changes, such as a
            heart-healthy diet, exercise, and, if necessary, medication, can
            help control these factors and protect your heart. Limit Alcohol
            Consumption:
            <h3 style={{ marginTop: "10px", marginBottom: "10px" }}>
              {" "}
              Limit Alcohol Consumption:{" "}
            </h3>
            While moderate alcohol consumption may have some cardiovascular
            benefits, excessive drinking can harm your heart. If you drink
            alcohol, do so in moderation. For men, this means up to two drinks
            per day, and for women, one drink per day. However, it's essential
            to consult with a healthcare professional, as certain individuals
            should avoid alcohol altogether.
            <h3 style={{ marginTop: "10px", marginBottom: "10px" }}>
              {" "}
              Get Enough Sleep:{" "}
            </h3>
            Adequate sleep is essential for heart health. Poor sleep quality and
            insufficient sleep can contribute to hypertension and other
            cardiovascular issues. Aim for 7-9 hours of quality sleep per night.
            Establish a consistent sleep schedule and create a relaxing bedtime
            routine to improve sleep patterns.
          </p>
          <h1>Other Important Points</h1>
          <p
            style={{
              fontSize: "20px",
              color: "#211f1b",
              fontFamily: "Montserrat",
          
              marginLeft: "10%",
              marginRight: "10%",
              textAlign: "justify",
            }}
          >
            <h3 style={{ marginTop: "10px", marginBottom: "10px" }}>
              Regular Health Checkups:{" "}
            </h3>
            Regular health checkups are essential for early detection and
            prevention of heart disease. Schedule regular visits with your
            healthcare provider to monitor your blood pressure, cholesterol
            levels, blood sugar, and other important health indicators.
            Detecting any potential issues early allows for timely intervention
            and better management of heart health. Know Your Family History:
            <h3 style={{ marginTop: "10px", marginBottom: "10px" }}>
              {" "}
              Know Your Family History:{" "}
            </h3>
            Understanding your family's medical history can provide valuable
            insights into potential hereditary risk factors for heart disease.
            If there is a history of heart conditions in your family, be
            proactive in adopting heart-healthy habits and work closely with
            your healthcare provider to manage any underlying risks. Stay
            Hydrated:
            <h3 style={{ marginTop: "10px", marginBottom: "10px" }}>
              {" "}
              Stay Hydrated:{" "}
            </h3>
            Proper hydration is crucial for heart health. Drinking an adequate
            amount of water helps maintain blood volume and supports healthy
            blood circulation. Aim to consume at least eight glasses of water
            daily and adjust your intake based on your activity level and
            climate. Limit Sodium Intake: Excess sodium can contribute to high
            blood pressure, a significant risk factor for heart disease. Be
            mindful of the amount of salt in your diet and opt for low-sodium
            alternatives when possible. Focus on using herbs and spices to
            enhance the flavor of your meals instead of relying on excessive
            salt. Practice Mindful Eating:
            <h3 style={{ marginTop: "10px", marginBottom: "10px" }}>
              Practice Mindful Eating:{" "}
            </h3>
            Mindful eating involves paying attention to the taste, texture, and
            enjoyment of food, as well as recognizing feelings of hunger and
            fullness. This practice can help prevent overeating, promote
            healthier food choices, and contribute to maintaining a healthy
            weight.
          </p>
          <h1>5 diet Tips for Better heart health</h1>
          <p
            style={{
              fontSize: "20px",
              color: "#211f1b",
              fontFamily: "Montserrat",
              marginLeft: "10%",
              marginRight: "10%",
              textAlign: "justify",
            }}
          >
            Here are five dietary tips for improving heart health:
            <h3 style={{ marginTop: "10px", marginBottom: "10px" }}>
              Focus on addition, not subtraction-{" "}
            </h3>
            Rather than eliminating all treats, start by incorporating more
            fruits and vegetables into your meals. These nutrient-rich options
            can help reduce blood pressure and cholesterol, while the fiber and
            crunchiness may satisfy your cravings. Frozen produce is a good
            alternative to fresh, and it's preferable to canned items. Switch up
            your protein sources-
            <h3 style={{ marginTop: "10px", marginBottom: "10px" }}>
              Switch up your protein sources-{" "}
            </h3>
            Red meat is high in saturated fat, which can raise cholesterol
            levels. Opt for chicken, fish, or beans instead. If you occasionally
            consume red meat, choose lean cuts like sirloin. Make healthier
            choices at fast-food restaurants-
            <h3 style={{ marginTop: "10px", marginBottom: "10px" }}>
              Make healthier choices at fast-food restaurants-{" "}
            </h3>
            When eating on the go, go for salads or grilled items over fried
            options. At Mexican chains, try veggie-filled bowls with cauliflower
            or brown rice rather than tortillas and white rice.
            <h3 style={{ marginTop: "10px", marginBottom: "10px" }}>
              Substitute butter with olive oil for cooking-{" "}
            </h3>
            This simple change retains flavor without increasing cholesterol.
            Extra virgin olive oil has much lower saturated fat compared to
            butter.
            <h3 style={{ marginTop: "10px", marginBottom: "10px" }}>
              Swap cold breakfast cereals with oatmeal-{" "}
            </h3>
            Many cold cereals are high in sugar and lacking in nutrients.
            Oatmeal is a whole grain that can help lower cholesterol and keep
            you feeling full longer due to its fiber content.
          </p>
          <h2>Conclusion:</h2>
          <p
            style={{
              fontSize: "20px",
              color: "#211f1b",
              fontFamily: "Montserrat",
              marginLeft: "10%",
              marginRight: "10%",
              textAlign: "justify",
            }}
          >
            Prioritizing a healthy heart is essential for a long and vibrant
            life. By adopting these preventive tips and considering other
            essential points, you can significantly reduce the risk of heart
            disease and improve your overall well-being. Remember that small
            lifestyle changes can make a big difference when it comes to heart
            health. Consult with your doctor from Bangalore Heart Care Centre at
            Sakra World Hospital for personalized advice and create a
            comprehensive plan tailored to your specific needs. Embrace these
            preventive measures and incorporate them into your daily life to
            support a healthy heart and a healthier you.
          </p>
        </Card.Body>
      </Card>
    </div>
  );
}
