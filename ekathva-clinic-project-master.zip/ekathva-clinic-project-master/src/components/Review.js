import React from "react";
import "bootstrap/dist/css/bootstrap.min.css"; // Import Bootstrap CSS
import "react-multi-carousel/lib/styles.css";
import Carousel from "react-multi-carousel";
import {
  MDBCard,
  MDBCardTitle,
  MDBCardText,
  MDBCardBody,
  MDBCardImage,
  MDBRow,
  MDBCol,
} from "mdb-react-ui-kit";

const responsive = {
  superLargeDesktop: {
    breakpoint: { max: 4000, min: 3000 },
    items: 5,
  },
  desktop: {
    breakpoint: { max: 3000, min: 1024 },
    items: 3,
  },
  tablet: {
    breakpoint: { max: 1024, min: 464 },
    items: 2,
  },
  mobile: {
    breakpoint: { max: 464, min: 0 },
    items: 1,
  },
};

const Review = () => {
  // Define your card data as an array
  const cardData = [
    // ... (your card data)
    {
      title: "Emily Johnson",
      text:"Outstanding care and exceptional staff! From admission to discharge, the team here was attentive and compassionate.  ", 
       img_src : "../helth_image/p1.jpg"
    },
    {
      title: "Marcus Rodriguez",
      text: "The clinic offers comprehensive services. Doctors are knowledgeable, and the staff is friendly. However, waiting ",
      img_src : "../helth_image/p2.jpg"
    },
    {
      title: "Sarah Chen",
      text: "Great facilities and modern equipment. The care received was excellent, but the administrative process needs streamlining",
      img_src : "../helth_image/p3.jpg"
    },
    {
      title: "Alex Thompson",
      text: "A holistic approach to health! The hospital excels in integrating various wellness practices. Staff are professional and caring",
      img_src : "../helth_image/p4.jpg"
    },
    {
      title: "Maya Patel",
      text: "Decent service overall, but there's room for improvement in cleanliness and communication. The doctors, however, are ",
      img_src : "../helth_image/p6.jpg"
    },
    {
      title: "Gabriel Brown",
      text: "Great facilities and modern equipment. The care received was excellent, but the administrative process needs streamlining",
      img_src : "../helth_image/p1.jpg"
    },{
      title: "Olivia Kim",
      text: "The clinic offers comprehensive services. Doctors are knowledgeable, and the staff is friendly. However, waiting times ",
      img_src : "../image/beneator.jpeg"
    },
    {
      title: "Lucas Garcia",
      text: " Outstanding care and exceptional staff! From admission to discharge, the team here was attentive and compassionate. ",
      img_src : "../image/b4.jpeg"
    },
  ];

  return (
    <div>
      <h1
        style={{ color: "#00b7ac", marginBottom: "50px", marginLeft: "30px" }}
      >Testimonials</h1>
    

    <div className="card-carousel">
      <Carousel
        responsive={responsive}
        autoPlay={true} // Enable auto-sliding
        infinite={true}
        showDots={false} // Hide the navigation buttons (left and right)
        containerClass="carousel-container" // Add this class for custom styling
        itemClass="carousel-item-padding" // Add this class for card gap
      >
        
        {cardData.map((card, index) => (
          <MDBCard key={index} style={{ maxWidth: "540px", margin :"20px", boxShadow: "3px 3px 5px 0px rgba(0,0,0,0.2)",}}>
            <MDBRow className="g-0">
              <MDBCol md="4">
                <MDBCardImage
                  src={card.img_src}
                  alt="..."
                  fluid
                  style = {{height:"100%",}}
                />
              </MDBCol>
              <MDBCol md="8">
                <MDBCardBody>
                  <MDBCardTitle style= {{fontSize:"22px",fontWeight:'800',fontFamily:"Montserrat",color: "black",paddingLeft:"20px",paddingTop:"20px"}}>{card.title}</MDBCardTitle>
                  <MDBCardText style= {{fontSize:"19px",fontWeight:'400',fontFamily:"Montserrat",color:"black",paddingLeft:"20px",paddingTop:"20px"}}>{card.text}</MDBCardText>
                </MDBCardBody>
              </MDBCol>
            </MDBRow>
          </MDBCard>
        ))}
      </Carousel>
    </div>
    </div>
  );
};

export default Review;
