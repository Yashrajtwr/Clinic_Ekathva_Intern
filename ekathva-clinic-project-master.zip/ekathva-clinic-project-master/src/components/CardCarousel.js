import React from "react";
import "bootstrap/dist/css/bootstrap.min.css"; // Import Bootstrap CSS
import "react-multi-carousel/lib/styles.css";
import Card from "react-bootstrap/Card";
import Carousel from "react-multi-carousel";

const responsive = {
  superLargeDesktop: {
    breakpoint: { max: 4000, min: 3000 },
    items: 5,
  },
  desktop: {
    breakpoint: { max: 3000, min: 1024 },
    items: 3,
  },
  tablet: {
    breakpoint: { max: 1024, min: 464 },
    items: 2,
  },
  mobile: {
    breakpoint: { max: 464, min: 0 },
    items: 1,
  },
};

const CardCarousel = () => {
  // Define your card data as an array
  const cardData = [
    // ... (your card data)
    {
      title: "Physiotherapy",
      text: "Physiotherapy is a unique treatment, generally used to cure people suffering from pain due to an illness, injury, or disability. It also promotes good health and fitness. Physiotherapy or physical therapy is designed with the help of the science of movement. It can help you overcome pain and improve your physical strength.",
    },
    {
      title: "Cardiology",
      text: "At Metrounited HealthCare, we have a team of highly qualified and experienced cardiologists, interventional cardiologists, and cardiac surgeons who provide comprehensive care for a wide range of cardiac conditions in adults & children.Treatment for Cardiac conditions offered at Metrounited HealthCare ranges from medication,",
    },
    {
      title: "Gastroenterology",
      text: "The branch of Gastroenterology at Metrounited Healthcare gives an extensive and cutting edge administration through the short term and ongoing offices. The office is monitored by regarded and experienced gastroenterologists, proficient clinical officials, gifted and caring paramedical staff, and all around prepared specialists. ",
    },
    {
      title: "Internal Medicine & Intensive Care",
      text: "Internal Medicine or Internal Care in Metrounited HealthCare deals with the prevention, diagnosis, and treatment of adult diseases. The internists (physicians specializing in internal medicine) are skilled in managing patients who are suffering from undifferentiated or multi-system disease processesand all around prepared and ",
    },
    {
      title: "Neuro Surgeon & Spine Surgery ",
      text: "Metrounited HealthCare Neurology Department provides clinical and diagnostic services for the treatment and care of brain, spinal cord and nerve diseases. Our state-of-the-art radiology department with the latest 1.5 T MRI, and 32 slice CT scan is greatly contributing towards early diagnosis, quick intervention & better treatment.",
    },
    {
      title: "Orthopedic Surgery",
      text: "Our Department of Orthopaedics provides comprehensive and world-class orthopaedics services. The expet team of consultants offer specialised care in the fields of complex trauma, proly-trauma and other sub-specialties of orthopaedics. It provides management for all disorders of bone, joint, and a variety ans also ",
    },
  ];

  return (
    <div className="card-carousel">
      <Carousel
        responsive={responsive}
        autoPlay={true} // Enable auto-sliding
        infinite={true}
        containerClass="carousel-container" // Add this class for custom styling
        itemClass="carousel-item-padding" // Add this class for card gap
      >
        {cardData.map((card, index) => (
          <Card
            key={index}
            border="light"
            className="custom-card"
            style={{
              margin: "10px",
              boxShadow: "3px 3px 5px 0px rgba(0,0,0,0.2)",
            }}
          >
            <Card.Header
              style={{

                fontWeight:"800",
                fontSize:"22px",
                background:"#3f5efb",
                fontFamily:"Montserrat",color: "black",
                 }}
            >
              {card.title}
            </Card.Header>
            <Card.Body>
              <Card.Text 
              style={{fontSize:"19px",color: "#211f1b",
                    fontFamily: "Montserrat",marginLeft:"10px"}}>
              {card.text}</Card.Text>
            </Card.Body>
          </Card>
        ))}
      </Carousel>
    </div>
  );
};

export default CardCarousel;
