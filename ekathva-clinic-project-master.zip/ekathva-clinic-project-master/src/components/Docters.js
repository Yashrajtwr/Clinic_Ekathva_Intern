import React from "react";
import "bootstrap/dist/css/bootstrap.min.css"; // Import Bootstrap CSS
import "react-multi-carousel/lib/styles.css";
import Carousel from "react-multi-carousel";
import {
  MDBCard,
  MDBCardTitle,
  MDBCardText,
  MDBCardBody,
  MDBCardImage,
  MDBRow,
  MDBCol,
} from "mdb-react-ui-kit";

const responsive = {
  superLargeDesktop: {
    breakpoint: { max: 4000, min: 3000 },
    items: 5,
  },
  desktop: {
    breakpoint: { max: 3000, min: 1024 },
    items: 3,
  },
  tablet: {
    breakpoint: { max: 1024, min: 464 },
    items: 2,
  },
  mobile: {
    breakpoint: { max: 464, min: 0 },
    items: 1,
  },
};

const Docters = () => {
  // Define your card data as an array
  const cardData = [
    // ... (your card data)
    {
      title: "Cardiologist",
      text:"Specializes in heart health, diagnosing and treating conditions such as heart disease, heart attacks, and abnormal heart ", 
       img_src : "../helth_image/d5.jpg"
    },
    {
      title: "Dermatologist",
      text: "Focuses on skin, hair, and nail health, treating conditions like acne, eczema, skin cancer, and other skin disorders. and health",
      img_src : "../helth_image/d6.jpg"
    },
    {
      title: "Pediatrician",
      text: "Specializes in the medical care of infants, children, and adolescents, focusing on their physical, emotional, and behavioral health.",
      img_src : "../helth_image/d7.jpg"
    },
    {
      title: "Oncologist",
      text: "Treats cancer and provides care for cancer patients, employing various therapies like chemotherapy, radiation, and surgery.",
      img_src : "../helth_image/d4.jpg"
    },
    {
      title: "Neurologist",
      text: "Deals with disorders of the nervous system, including the brain, spinal cord, and nerves, diagnosing and treating conditions ",
      img_src : "../helth_image/d5.jpg"
    },
    {
      title: "Gynecologist",
      text: "Focuses on women's reproductive health, dealing with issues related to the female reproductive system, performing pap smears",
      img_src : "../helth_image/d6.jpg"
    },{
      title: "Psychiatrist",
      text: "Diagnoses and treats mental health disorders, prescribing medications and offering therapy to manage conditions like depression",
      img_src : "../helth_image/d7.jpg"
    },
    {
      title: "Endocrinologist",
      text: " Specializes in disorders related to the endocrine system, such as diabetes, thyroid issues, and hormonal imbalances. and health",
      img_src : "../helth_image/d8.jpg"
    },
  ];

  return (
    <div>
      <h1
        style={{ color: "#00b7ac", marginBottom: "50px", marginLeft: "30px", marginTop:"40px"}}
      >Docters</h1>
    

    <div className="card-carousel">
      <Carousel
        responsive={responsive}
        autoPlay={true} // Enable auto-sliding
        infinite={true}
        showDots={false} // Hide the navigation buttons (left and right)
        containerClass="carousel-container" // Add this class for custom styling
        itemClass="carousel-item-padding" // Add this class for card gap
      >
        
        {cardData.map((card, index) => (
          <MDBCard key={index} style={{ maxWidth: "540px", margin :"20px", boxShadow: "3px 3px 5px 0px rgba(0,0,0,0.2)",}}>
            <MDBRow className="g-0">
              <MDBCol md="4">
                <MDBCardImage
                  src={card.img_src}
                  alt="..."
                  fluid
                  style={{width:"100%",height:"100%"}}
                />
              </MDBCol>
              <MDBCol md="8">
                <MDBCardBody>
                <MDBCardTitle style= {{fontSize:"22px",fontWeight:'800',fontFamily:"Montserrat",color: "black",paddingLeft:"20px",paddingTop:"20px"}}>{card.title}</MDBCardTitle>
                  <MDBCardText style= {{fontSize:"19px",fontWeight:'400',fontFamily:"Montserrat",color:"black",paddingLeft:"20px",paddingTop:"20px"}}>{card.text}</MDBCardText>
                </MDBCardBody>
              </MDBCol>
            </MDBRow>
          </MDBCard>
        ))}
      </Carousel>
    </div>
    </div>
  );
};

export default Docters;
