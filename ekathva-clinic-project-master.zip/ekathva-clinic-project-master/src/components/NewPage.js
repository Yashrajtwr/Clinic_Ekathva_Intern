import React from "react";
import {Link} from "react-router-dom";
function NewPage(){
    return (
        <div>
      <>
        <footer className="bg-dark text-center text-white">
          <div className="container p-4">
            <section className="mb-4">
            <Link  class="list-inline" to="/">
          <img
              src="/image/ek_icon.png"
              alt="Logo"
              width="40"
              height="30"
              margin="30px"
              class="d-inline-block align-text-top"
            />
          
            
          </Link>

              <Link  class="list-inline" to="/">
          <img
              src="/image/facebook.png"
              alt="Logo"
              width="40"
              height="30"
              margin="30px"
              class="d-inline-block align-text-top"
            />
          
            
          </Link>
          <Link  class="list-inline" to="/">
          <img
              src="/image/google.png"
              alt="Logo"
              width="40"
              height="30"
              class="d-inline-block align-text-top"
            />
            
          </Link>
          <Link  class="list-inline" to="/">
          <img
              src="/image/twitter.png"
              alt="Logo"
              width="40"
              height="30"
              class="d-inline-block align-text-top"
            />
            
          </Link>
          <Link  class="list-inline" to="/">
          <img
              src="/image/phone.png"
              alt="Logo"
              width="40"
              height="30"
              class="d-inline-block align-text-top"
            />
            
          </Link>


              
              

             
            </section>
            <section className="">
              <form action="">
                <div className="row d-flex justify-content-center">
                  <div className="col-auto">
                    <p className="pt-2">
                      <strong>Sign up for our newsletter</strong>
                    </p>
                  </div>
                  <div className="col-md-5 col-12">
                    <div className="form-outline form-white mb-4">
                      <input
                        type="email"
                        id="form5Example21"
                        className="form-control"
                      />
                      <label className="form-label" htmlFor="form5Example21">
                        Email address
                      </label>
                    </div>
                  </div>
                  <div className="col-auto">
                    <button
                      type="submit"
                      className="btn btn-outline-light mb-4"
                    >
                      Subscribe
                    </button>
                  </div>
                </div>
              </form>
            </section>
            <section className="mb-4">
              <p>
                Ekathva Metrounited HealthCare is formed with a vision to give the best<br></br>
                possible medical care and support for patients to overcome any
                health situation.
              </p>
            </section>
            <section className="">
              <div className="row">
                <div className="col-lg-3 col-md-6 mb-4 mb-md-0"></div>
              </div>
            </section>
          </div>
          <div
            className="text-center p-3"
            style={{ backgroundColor: "rgba(0, 0, 0, 0.2)" }}
          >
            © 2022 Copyright:
            
          </div>
        </footer>
      </>
    </div>
    );
}
export default NewPage;
