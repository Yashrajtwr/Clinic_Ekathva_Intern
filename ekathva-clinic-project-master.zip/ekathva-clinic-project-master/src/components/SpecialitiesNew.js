import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css'; // Import Bootstrap CSS
import 'react-multi-carousel/lib/styles.css';
import CardCarousel from "./CardCarousel";


const SpecialitiesNew = () => {
  // Define your card data as an array
  

  return (
    <div>
      <CardCarousel/>
    </div>
  );
};

export default SpecialitiesNew;
