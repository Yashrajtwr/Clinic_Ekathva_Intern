import React from "react";
import SpecialitiesNew from "./SpecialitiesNew";

export default function Specialities1() {
  return (
    <div>
        <SpecialitiesNew/>
        <SpecialitiesNew/>
        <SpecialitiesNew/>
        <SpecialitiesNew/>
    </div>
  );
}
