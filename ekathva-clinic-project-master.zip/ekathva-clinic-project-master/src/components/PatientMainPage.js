import React from 'react'
import { MDBCard, MDBCardBody } from 'mdb-react-ui-kit';

export default function PatientMainPage() {

    return (
    <div>
       <MDBCard>
      <MDBCardBody>This is some text within a card body.</MDBCardBody>
    </MDBCard>
    </div>
  )
}
