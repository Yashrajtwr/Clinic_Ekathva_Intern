import React from "react";
import Button from "react-bootstrap/Button";

import "bootstrap/dist/css/bootstrap.min.css";
import "@coreui/coreui/dist/css/coreui.min.css";
import { CCard, CCardBody } from "@coreui/react";
function ShortStory() {

  

  return (
    <>
      <CCard className="info" style={{  boxShadow: "3px 3px 5px 0px rgba(0,0,0,0.1)",}}>
        
        <CCardBody>
          <h1 style={{ color: "linear-gradient(to right, #4e54c8, #8f94fb)",}}>Short Story About Ekathva Clinic HealthCare, Shivamogga.</h1>
          <img
            src="/image/about_img.jpg"
            align="left"
            width="40%"
            height="30%"
            class="img_left"
            alt = ""
          />
          <p class="p1" style={{fontSize:"20px",color: "#211f1b",
                    fontFamily: "Montserrat",marginLeft:"10px"}}>
          Ekathva Clinic Hospital has equipped its departments with the latest,
            state-of-the-art medical and surgical equipments to deliver the
            safest medical care to its patients.Our medical team of skilled
            professionals who excel in their clinical and surgical skills. We
            assure, their commitment to patients will be unmatched along with
            their dedication to treat them with utmost care and give them the
            right cost-effective treatment.Our Vision is to give best possible
            medical care and support for patients to overcome any healthTo
            provide leading edge healthcare services with commitment, compassion
            and excellence to achieve optimal quality life for the people we
            serve. situation.
          </p><br></br>
          <ul class="li1">
            <li><img  alt = "" src="image/check.ico" width="30" height="30" margin-right="10%"/>Painless Dental Treatment</li>
            <li><img alt = ""  src="image/check.ico" width="30" height="30"/>Experinced Dental Professionals</li>
            <li><img alt = "" src="image/check.ico" width="30" height="30"/>Flexiable Payment Options</li>
            <li><img alt = "" src="image/check.ico" width="30" height="30"/>Beautiful Simle Design</li>
          </ul>
           <br></br>
           <br></br> <br></br>
           <Button variant="primary" >
            More About
          </Button>
        </CCardBody>
      </CCard>
      
    </>
  );
}

export default ShortStory;
