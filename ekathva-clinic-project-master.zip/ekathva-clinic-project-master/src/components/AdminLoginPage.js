import React from "react";
import { useState } from "react";
import { auth } from "./Database";
import { signInWithEmailAndPassword } from "firebase/auth";
import { useNavigate } from "react-router-dom";
import {
  CCard,
  CCardBody,
  CCardTitle,

  CFormInput,

  CForm,

  CButton,
  CCardHeader,
  CCardText,

} from "@coreui/react";
import { toast } from "react-toastify";
import LogInPage from "./LogInPage";

function AdminLogInPage() {
  const [newEmail, setNewEmail] = useState("");
  const [newPassword, setNewPassword] = useState("");
  let navigate = useNavigate();
  const LogIn = async () => {
    try{
        await signInWithEmailAndPassword(
        auth,
        newEmail,
        newPassword
      ); 
      toast.success("Log in success ");
      navigate("/AdminMainPage");
    }catch(err){
      toast.error(err);
    }
  };

  return (
    <div>
      <>
      <LogInPage/>
        <CCard className="info">
          <CCardHeader>Admin Log In</CCardHeader>
          <CCardBody>
            <CCardTitle> Admin LogIn</CCardTitle>
            <CCardText>
              
            </CCardText>

            <CForm>
              <CFormInput
                type="email"
                id="exampleFormControlInput1"
                label="Email address"
                placeholder="name@example.com"
                aria-describedby="exampleFormControlInputHelpInline"
                onChange={(event) => {
                  setNewEmail(event.target.value);
                }}
              />
            </CForm>

            <CForm>
              <CFormInput
                type="password"
                id="exampleFormControlInput1"
                label="Enter the password"
                text="Must be 8-20 characters long."
                aria-describedby="exampleFormControlInputHelpInline"
                onChange={(event) => {
                  setNewPassword(event.target.value);
                }}
              />
            </CForm>

            <CButton onClick={LogIn}>LOG IN</CButton>
          </CCardBody>
        </CCard>
      </>
    </div>
  );
}

export default AdminLogInPage;
