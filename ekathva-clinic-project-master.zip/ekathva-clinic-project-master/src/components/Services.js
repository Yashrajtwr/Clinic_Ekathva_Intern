import React from "react";
import Button from "react-bootstrap/Button";

import "bootstrap/dist/css/bootstrap.min.css";
import "@coreui/coreui/dist/css/coreui.min.css";
import {
  CCard,
  CCardBody,
  CCardText,
  CCardTitle,
  CCardSubtitle,
  CCardImage,
} from "@coreui/react";

export default function Services() {
  return (
    <div>
      <CCard className="info">
        <CCardBody>
          <h1> Our Services At Ekathva Clinic Healthcare</h1>
          <img
            src="/image/metro_services.png"
            align="right"
            width="50%"
            height="50%"
            class="img_right"
            alt=""
          />
          <p class="p1">
            A premier helathcare provider in shivamogga, Ekathva Clinic Healthcare
            established in 2015 to give best possible medical support services
            or patient care.
          </p>
          <br></br>
          <ul class="li_in">
            <li>
              <img src="/image/medical_beds.png" width="40" height="40" alt=""/>
              <h5>135Beds</h5>
            </li>
            <li>
              <img src="/image/operation_theatre.png" width="40" height="40" alt="" />
              <h5>3 Operation Theatres</h5>
            </li>
            <li>
              <img
                src="/image/inpatient_outpatient.png"
                width="40"
                height="40"
                alt=""
              />
              <h5>Inpatient Outpatient Services</h5>
            </li>
            <li>
              <img src="/image/radiology.png" width="40" height="40" alt=""/>
              <h5>Radiology</h5>
            </li>
            <li>
              <img src="/image/laboratory.png" width="40" height="40"alt="" />
              <h5>Laboratory</h5>
            </li>
            <li>
              <img src="/image/emergency.png" width="40" height="40" alt=""/>
              <h5>24/7 Emergency</h5>
            </li>
            <li>
              <img src="/image/pharmacy.png" width="40" height="40" alt=""/>
              <h5>24/7 Pharmacy</h5>
            </li>
            <li>
              <img src="/image/day_care.png" width="40" height="40" alt=""/>
              <h5>Day Care</h5>
            </li>
          </ul>
          <br></br>

          <Button variant="primary">More About</Button>
        </CCardBody>
      </CCard>

      <CCard className="info">
        <CCardBody style={{margin :"10px"}}>
          <div class="row row-cols-1 row-cols-md-3 g-4 ">
            <CCard style={{ width: "18rem", margin :"10px"}}>
              <CCardBody>
                <CCardTitle>Laboratory</CCardTitle>
                <CCardSubtitle className="mb-2 text-medium-emphasis"></CCardSubtitle>
                <CCardImage  orientation="top" src="/image/lab.png" alt="" width="10" height="90"/>
                <CCardText>
                  MetroUnited HealthCare has one of the most advanced Laboratory
                  set-ups in Shivamogga.
                </CCardText>
              </CCardBody>
            </CCard>

            <CCard style={{ width: "18rem" ,margin :"10px"}}>
              <CCardBody>
                <CCardTitle>CT Scan, Xray</CCardTitle>
                <CCardSubtitle className="mb-2 text-medium-emphasis"></CCardSubtitle>
                <CCardImage  orientation="top" src="/image/Xray.png" width="10" height="90" alt=""/>
                <CCardText>
                  Medical CT Scan, Xray professionals provide clinical
                  information and services that contribute to the effective
                  delivery of care in today's complex Hospital.
                </CCardText>
              </CCardBody>
            </CCard>

            <CCard style={{ width: "18rem",margin :"10px" }}>
              <CCardBody>
                <CCardTitle>ECG, Echocardiogram, TMT, USG</CCardTitle>
                <CCardSubtitle className="mb-2 text-medium-emphasis"></CCardSubtitle>
                <CCardImage  orientation="top" src="/image/tmt.png" width="10" height="90" alt=""/>
                <CCardText>
                  We offer electrocardiography or echocardiogram ECG,
                  Treadmill test TMT at ... for which ultrasound-based
                  echocardiography or nuclear medicine tests.
                </CCardText>
              </CCardBody>
            </CCard>

            <CCard style={{ width: "18rem" ,margin :"10px"}}>
              <CCardBody>
                <CCardTitle>Health Monitoring</CCardTitle>
                <CCardSubtitle className="mb-2 text-medium-emphasis"></CCardSubtitle>
                <CCardImage  orientation="top" src="/image/helth.png" width="5" height="100" alt=""/>
                <CCardText>
                  The health monitor is a type of portable electrocardiogram
                  ECG. health monitoring services available 24*7.
                </CCardText>
              </CCardBody>
            </CCard>
          </div>
        </CCardBody>
      </CCard>
    </div>
  );
}
