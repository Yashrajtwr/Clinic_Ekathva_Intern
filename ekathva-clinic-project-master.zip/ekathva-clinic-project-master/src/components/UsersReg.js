import React from "react";
import { useState } from "react";
import { db } from "./Database";
import { collection, addDoc } from "firebase/firestore";
function UsersReg() {
  const [newName, setNewName] = useState("");
  const [newAge, setNewAge] = useState(0);
  const [newGender, setNewGender] = useState("");
  const [newPhysician, setNewPhysician] = useState("");
  const [newMobileNumber, setNewMobileNumber] = useState(0);
  const [newCity, setNewCity] = useState("");
  const [newAddress, setNewAddress] = useState("");
  const [newPayment, setNewPhyment] = useState("");

  const usersCollectionRef = collection(db, "users");
  const createUsers = async () => {
    await addDoc(usersCollectionRef, {
      name: newName,
      age: newAge,
      gender: newGender,
      physician: newPhysician,
      mobile_number: newMobileNumber,
      city: newCity,
      address: newAddress,
      paymment: newPayment,
    });
    alert("Registraction is sucessuces");
  };

  return (
    <>

<div class="wrapper">
        <h2>Registration</h2>
        <form action="#">
            <div class="input-box">
      <input
        placeholder="name"
        required
        onChange={(event) => {
          setNewName(event.target.value);
        }}
      />
      </div>
      <div class="input-box">
      <input
      required
        type="number"
        placeholder="age"
        onChange={(event) => {
          setNewAge(event.target.value);
        }}
      />
      </div>

      <div class="input-box">
      <select
      value={newGender}
        id="country"
        onChange={(event) => {
          setNewGender(event.target.value);
        }}
      >
        <option >Male</option>
        <option>Femail</option>
        <option >Undefined</option>
      </select>
      </div>
      <div class="input-box">
      <select
        value={newPhysician}
        id="country"
        onChange={(event) => {
          setNewPhysician(event.target.value);
        }}
      >
        <option >Umesha</option>
        <option >Yash Raj</option>
        <option >Sudeepa</option>
        <option >Akarsh</option>
        <option >Mahi</option>
        <option >Sudeepaa</option>
      </select>
      </div>
      <div class="input-box">
      <input
      required
        placeholder="Mobile NUmber"
        type="number"
        onChange={(event) => {
          setNewMobileNumber(event.target.value);
        }}
      />
</div>
<div class="input-box">
      <input
      required
        placeholder="City"
        onChange={(event) => {
          setNewCity(event.target.value);
        }}
      />
      </div>
      <div class="input-box">
      <input
      required
        placeholder="Address"
        onChange={(event) => {
          setNewAddress(event.target.value);
        }}
      />
      </div>
      <div class="input-box">
      <select
      value={newPayment}
        id="country"
        onChange={(event) => {
          setNewPhyment(event.target.value);
        }}
      >
        <option >Online</option>
        <option>Cash</option>
      </select>
      </div>

      <button type="Registration" class="btn btn-danger" onClick={createUsers}>
      Register
                        </button>
      </form>
    </div>
      
    </>
  );
}

export default UsersReg;
