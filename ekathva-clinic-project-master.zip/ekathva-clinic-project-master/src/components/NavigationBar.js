import React from "react";
import { Link } from "react-router-dom";
import Navbar from "react-bootstrap/Navbar";
import Nav from "react-bootstrap/Nav";
import Button from "react-bootstrap/Button";
import Dropdown from "react-bootstrap/Dropdown";



function NavigationBar() {
  return (
    <Navbar bg="primary" expand="lg" fixed="top" variant="dark">
      <div className="container">
        <Navbar.Brand as={Link} to="/">
          <img
            src="/image/ek_icon.png"
            alt="Logo"
            width="40"
            height="30"
            className="d-inline-block align-text-top"
          />
          <span className="text-white">Ekathva Clinic</span>
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="navbarSupportedContent" />
        <Navbar.Collapse id="navbarSupportedContent">
          <Nav className="me-auto">
            <Nav.Link as={Link} to="/">
              <Dropdown>
                <Dropdown.Toggle variant="success" id="dropdown-basic">
                  Centre Of Excellence
                </Dropdown.Toggle>

                <Dropdown.Menu>
                  <Dropdown.Item as = {Link} to ="/CentreofExcellence"> Centre Of Excellence</Dropdown.Item>
      

                  <Dropdown.Item as = {Link} to = "/CancerCarePage">
                    Cancer Care
                  </Dropdown.Item>
                  
                </Dropdown.Menu>
              </Dropdown>
            </Nav.Link>
            <Nav.Link as={Link} to="/">
              Home
            </Nav.Link>

            <Nav.Link as={Link} to="/Services">
              Services
            </Nav.Link>
            <Nav.Link as={Link} to="/Specialities1">
              Specialties
            </Nav.Link>
            <Nav.Link as={Link} to="/AboutPage">
              About
            </Nav.Link>
            <Nav.Link as={Link} to="/Docters">
              Docters
            </Nav.Link>
            <Nav.Link as={Link} to="/Contact">
              Contact
            </Nav.Link>
          </Nav>
          <div className="d-flex">
            <Link to="/AdminLogInPage">
              <Button variant="outline-primary" className="text-white ms-2">
                Log In
              </Button>
            </Link>
            <Link to="/SignUpPage">
              <Button variant="outline-primary" className="text-white ms-2">
                Sign Up
              </Button>
            </Link>
          </div>
        </Navbar.Collapse>
      </div>
    </Navbar>
  );
}

export default NavigationBar;
