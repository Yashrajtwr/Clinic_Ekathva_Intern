import React from "react";
import "bootstrap/dist/css/bootstrap.min.css"; // Import Bootstrap CSS
import "react-multi-carousel/lib/styles.css";
import Card from "react-bootstrap/Card";
import Carousel from "react-multi-carousel";
import Button from "react-bootstrap/Button";




const responsive = {
  superLargeDesktop: {
    breakpoint: { max: 4000, min: 3000 },
    items: 5,
  },
  desktop: {
    breakpoint: { max: 3000, min: 1024 },
    items: 3,
  },
  tablet: {
    breakpoint: { max: 1024, min: 464 },
    items: 2,
  },
  mobile: {
    breakpoint: { max: 464, min: 0 },
    items: 1,
  },
};
const TreatmentProcedures = () => {
  // Define your card data as an array
  const cardData = [
    // ... (your card data)
    {
      title: "Chemotherapy",
      text: "Chemotherapy has been the accepted therapeutic paradigm for the treatment of advanced cancers. This mode of treatment involves the use of systemic chemotherapy drugs which target specific areas where cancer cells grow.",
    },
    {
      title: "Colposcopy clinic",
      text: "Colposcopy is a diagnostic procedure in which a colposcope (a dissecting microscope with various magnification lenses) is used to provide an illuminated magnified view of the cervix, vagina, vulva or anus to identify precancerous and cancerous lesions so that they may be treated early.",
    },
    {
      title: "Core Biopsy",
      text: "A core biopsy is a procedure where a needle is passed through the skin to obtain a sample of tissue from a mass or lump. The tissue sample is then examined under a microscope for any abnormalities." },
    {
      title: "Biological therapy",
      text: "This therapy of cancer treatment uses the body's immune system to kill cancer cells. Biological therapy for cancer is used in the treatment of many types of cancer to prevent or slow tumor growth and to prevent the spread of cancer"},
    {
      title: "Day care and domiciliary chemotherapy",
      text: "Day care chemotherapy is extended to those patients who have been advised short therapies or cancer procedures that do not require a night stay in hospital. Domiciliary chemotherapy involves making chemotherapy services available to cancer patients in their homes. This is mostly for the elderly who cannot reach the hospital for chemotherapy sessions.      " },
    {
      title: "Bone Marrow Transplant for benign",
      text: "Bone marrow transplant is a procedure where a person's faulty bone marrow stem cells are replaced by healthy ones. Bone marrow transplants are done to treat patients suffering from leukemia, and severe blood diseases such as thalassemias, aplastic anemia, and sickle cell anemia, as well as multiple myeloma and certain immune deficiency diseases." },
      {
        title: "PICC, bone marrow aspiration and",
        text: "A PICC is a thin, flexible tube that is inserted into a vein in the upper arm and guided into a large vein above the right side of the heart called the superior vena cava. It is used to give intravenous fluids, blood transfusions, chemotherapy, and other drugs. Bone marrow aspiration is the removal of a small amount of this tissue in liquid from "},
      {
        title: "Central line and chemo port use",
        text: "In some cancer patients, chemotherapy is safely delivered through a standard (or “peripheral”) IV line. Other times, infusions must be administered through a central line catheter, such as a PICC, CVC or port." },
      {
        title: "Palliative care",
        text: "Palliative care is the holistic approach to cancer care that addresses the patient as a whole, not just their disease. It also means learning to manage the cancer symptoms and side effects.        " },
    ];

  return (
    <div style={{ margin: "20px", marginTop: "50px", marginBottom: "50px" }}>
      <h1
        style={{ color: "#00b7ac", marginBottom: "50px", marginLeft: "30px" }}
      >
        Treatment and Procedures
      </h1>

      <div className="card-carousel">
        <Carousel
          responsive={responsive}
          autoPlay={true} // Enable auto-sliding
          infinite={true}
          containerClass="carousel-container" // Add this class for custom styling
          itemClass="carousel-item-padding" // Add this class for card gap
        >
          {cardData.map((card, index) => (
            <Card
              key={index}
              border="primary"
              className="custom-card"
              style={{ margin: "10px", height:"500px",boxShadow: "3px 3px 5px 0px rgba(0,0,0,0.2)", }}
            >
              <Card.Body style={{ padding: "20px"}}>
                <Card.Title
                  style={{
                    fontSize: "30px",
                    color: "#034ea1",
                    marginBottom: "30px",
                    marginTop: "30px",
                  }}
                >
                  {card.title}
                </Card.Title>
                <Card.Text
                  style={{
                    color: "#211f1b",
                    fontFamily: "Montserrat",
                    fontSize: "20px",
                  }}
                >
                  {card.text}
                </Card.Text>
                <Button variant="primary"
                  style={{
                    position: "absolute",
                    bottom: "10px",
                    left: "10px",
                    boxShadow: "3px 3px 5px 0px rgba(0,0,0,0.5)",
                    background: "linear-gradient(to right, #4e54c8, #8f94fb)",
                    color: "white",
                    border: "none",
                    padding: "10px 20px",
                    borderRadius: "5px",
                  }}
                >Know More.</Button>
              </Card.Body>
            </Card>
          ))}
        </Carousel>
      </div>
    </div>
  );
};

export default TreatmentProcedures;
