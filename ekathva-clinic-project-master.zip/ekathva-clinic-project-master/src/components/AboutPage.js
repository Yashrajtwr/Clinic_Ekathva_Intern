import React from "react";
import Card from "react-bootstrap/Card";
import {
  CCard,
  CCardBody,
  CCardTitle,
  CCol,
  CCardImage,
  CCardText,
  CRow,
  CContainer,
  CCallout
} from "@coreui/react";
import ContactUs1 from "./ContactUs1";

export default function AboutPage() {

  return (
    <>
      <CCard className="mb-3" style={{ maxWidth: "100%", margin: "30px" }}>
        <CRow className="g-0">
          <CCol md={4}>
            <CCardImage src="/image/We_Have_Advanced_Technology.png"  alt=""/>
          </CCol>
          <CCol md={8}>
            <CCardBody>
              <CCardTitle>We Have Advanced Technologies</CCardTitle>
              <CCardText>
                Metrounited Healthcare is formed with a vision to give best
                possible medical care and support for patients to overcome any
                health situation. Here, at Metrounited Healthcare, the
                infrastructure and facilities are optimally combined to obtain
                quick and qualitative results in the improvement of patient's
                health condition. The facilities at Metrounited Healthcare
                include 135 beds, 37 bedded ICUS with all modern facilities, 3
                Ultra- modern operation theaters, and a state-of-the art
                cathlab. 24X7 Trauma and Emergency care, 24x7 Laboratory, 24x7
                Pharmacy, 24x7 CT.Scan and X-ray, USG, Echocardiography, TMT
                Internal medicine, Cardiology, General and Laparoscopic Surgery,
                Urology, Neuro Surgery and Orthopedics surgery. Our experienced
                doctors and staffs give their best in providing proper care and
                support for patients to overcome their Eation and come back to
                normal life.
                <br></br>
                <br></br>
                <br></br>
                <ContactUs1 />
              </CCardText>
              <CCardText>
                <small className="text-medium-emphasis">
                  Last updated 3 mins ago
                </small>
              </CCardText>
            </CCardBody>
          </CCol>
        </CRow>
      </CCard>

      <div class="row row-cols-1 row-cols-md-3 g-4 ">
        <div className="c1">
        <Card
            border="primary"
            style={{ margin: "30px", width: "23rem", height: "15rem" }}
          >
          
            <Card.Header>Our Mission</Card.Header>
            <Card.Body>
              <Card.Title>Our Mission</Card.Title>
              <Card.Text>
                "Our Vision is to give best possible medical care and support
                for patients to overcome any health situation."
              </Card.Text>
            </Card.Body>
          </Card>
        </div>
        <div className="c1">
          <Card
            border="primary"
            style={{ margin: "30px", width: "23rem", height: "15rem" }}
          >
            <Card.Header>Our Vision</Card.Header>
            <Card.Body>
              <Card.Title>Our Vision</Card.Title>
              <Card.Text>
                To provide leading edge healthcare services with commitment,
                compassion and excellence to achieve optimal quality life for
                the people we serve.
              </Card.Text>
            </Card.Body>
          </Card>
        </div>
        <div className="c1">
          <Card
            border="primary"
            style={{ margin: "30px", width: "23rem", height: "15rem" }}
          >
            <Card.Header>Our Values</Card.Header>
            <Card.Body>
              <Card.Title>Our Values</Card.Title>
              <Card.Text>
                We provide a compassionate and caring experience for our
                patients and residents, their families and our staff.{" "}
              </Card.Text>
            </Card.Body>
          </Card>
        </div>
      </div>

      
     
      <CCallout color="info">
      <CContainer>
        <CRow>
          <CCol>
            <img src="image/export_docter.png" alt=""/>
            <h1>200+</h1>Expert Doctors
          </CCol>
          <CCol xs={{ span: true, order: 5 }}>
            <img src="image/helth.png" alt="" />
            <h1>1,00,000+</h1>Happy Patients
          </CCol>
          <CCol xs={{ span: true, order: 1 }}>
            <img src="image/medical_beds.png" alt="" width="63" height="63" />
            <h1>200</h1>Medical Beds
          </CCol>
        </CRow>
      </CContainer>
      </CCallout>

      
    </>
  );
}
