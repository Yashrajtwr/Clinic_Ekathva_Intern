import React from 'react'
import { useState, useEffect } from "react";
import { db } from "./Database";
import { collection, getDocs } from "firebase/firestore";

export default function QuickContact() {
    const [patient, setPatient] = useState([]);
  const patientData = collection(db, "ContactUs");

  useEffect(() => {
      const getUsers = async () => {
      const data = await getDocs(patientData);
      setPatient(data.docs.map((doc) => ({ ...doc.data(), id: doc.id })));
    };
    getUsers();
  }, [patientData]);
  return (
    <div>
        <div class="card  text-center info ">
      <div class="card-header">Quick Contact Data</div>
      <div class="card-body ">
        <div className="table">
          <>
            <div class="table-responsive table-wrapper-scroll-y my-custom-scrollbar ">
              <table class="table ">
                <tr>
                  <th scope="col">First Name</th>
                  <th scope="col">Middle Name</th>
                  <th scope="col">Last Name</th>
                  <th scope="col">Email</th>
                  <th scope="col">discription</th>
                  <th scope="col">Edit</th>
                  <th scope="col">Delete</th>
                  <th scope="col">Email</th>
                </tr>
                {""}
                {patient.map((SignUp) => {
                  return (
                    <tbody>
                      <tr>
                        <td>{SignUp.first_name}</td>
                        <td>{SignUp.middle_name}</td>
                        <td>{SignUp.last_name}</td>
                        <td>{SignUp.email}</td>
                        <td>{SignUp.discription}</td>
                        <td>
                          <button type="button" class="btn btn-primary">
                            Edit{" "}
                          </button>
                        </td>
                        <td>
                          <button type="button" class="btn btn-danger">
                            Delete
                          </button>
                        </td>
                        <td>
                          <button type="button" class="btn btn-danger">
                            Email
                          </button>
                        </td>
                      </tr>
                    </tbody>
                  );
                })}
              </table>
            </div>
          </>
        </div>
      </div>
      <div class="card-footer text-muted">2 days ago</div>
    </div>
    </div>
  )
}
