import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";
import Modal from "react-bootstrap/Modal";
import React, { useState } from "react";
import { db } from "./Database";
import { collection } from "firebase/firestore";
import { addDoc } from "firebase/firestore";
import { toast } from "react-toastify";

export default function ContactUs1() {
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [middleName, setMiddleName] = useState("");
  const [email, setEmail] = useState("");
  const [discription, setDiscription] = useState("");

  const database_ob1 = collection(db, "ContactUs");

  const insert = async () => {
    if (firstName !== "") {
      if (middleName !== "") {
        if (lastName !== "") {
          if (email !== "") {
            if (discription !== "") {
              await addDoc(database_ob1, {
                first_name: firstName,
                last_name: lastName,
                middle_name: middleName,
                email: email,
                discription: discription,
              });

              toast.success("The data Added Successfully....!");
            } else {
              toast.info("Enter discription name.");
            }
          } else {
            toast.info("Enter Email name.");
          }
        } else {
          toast.info("Enter last name.");
        }
      } else {
        toast.info("Enter the middle name.");
      }
    } else {
      toast.info("Enter the first name.");
    }
  };

  return (
    <div>
      <Button variant="primary" onClick={handleShow}>
        Contact Us
      </Button>
      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Enter details</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
              <Form.Label>Enter the First Name</Form.Label>
              <Form.Control
                type="name"
                placeholder="Enter Name"
                autoFocus
                onChange={(event) => {
                  setFirstName(event.target.value);
                }}
              />
              <Form.Group
                className="mb-3"
                controlId="exampleForm.ControlInput1"
              >
                <Form.Label>Enter the middle Name</Form.Label>
                <Form.Control
                  type="name"
                  placeholder="Enter the Middle Name"
                  onChange={(event) => {
                    setMiddleName(event.target.value);
                  }}
                />
              </Form.Group>
              <Form.Group
                className="mb-3"
                controlId="exampleForm.ControlInput1"
              >
                <Form.Label>Enter the Last Name</Form.Label>
                <Form.Control
                  type="name"
                  placeholder="Enter the Last Name"
                  onChange={(event) => {
                    setLastName(event.target.value);
                  }}
                />
              </Form.Group>
            </Form.Group>
            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
              <Form.Label>Email address</Form.Label>
              <Form.Control
                type="email"
                placeholder="name@example.com"
                onChange={(event) => {
                  setEmail(event.target.value);
                }}
              />
            </Form.Group>
            <Form.Group
              className="mb-3"
              controlId="exampleForm.ControlTextarea1"
            >
              <Form.Label>description</Form.Label>
              <Form.Control
                as="textarea"
                rows={3}
                onChange={(event) => {
                  setDiscription(event.target.value);
                }}
              />
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" onClick={insert}>
            Send.
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
}
