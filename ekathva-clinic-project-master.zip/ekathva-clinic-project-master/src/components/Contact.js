import { MDBCard, MDBCardBody } from "mdb-react-ui-kit";
import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";
import Modal from "react-bootstrap/Modal";
import React, { useState } from "react";
import { db } from "./Database";
import { collection } from "firebase/firestore";
import { addDoc } from "firebase/firestore";
import { toast } from "react-toastify";

export default function Contact() {

  const [show, setShow] = useState(true);

  const handleClose = () => setShow(false);


  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [middleName, setMiddleName] = useState("");
  const [email, setEmail] = useState("");
  const [discription, setDiscription] = useState("");

  const database_ob1 = collection(db, "ContactUs");

  const insert = async () => {
    if (firstName !== "") {
      if (middleName !== "") {
        if (lastName !== "") {
          if (email !== "") {
            if (discription !== "") {
              await addDoc(database_ob1, {
                first_name: firstName,
                last_name: lastName,
                middle_name: middleName,
                email: email,
                discription: discription,
              });

              toast.success("The data Added Successfully....!");
            } else {
              toast.info("Enter discription name.");
            }
          } else {
            toast.info("Enter Email name.");
          }
        } else {
          toast.info("Enter last name.");
        }
      } else {
        toast.info("Enter the middle name.");
      }
    } else {
      toast.info("Enter the first name.");
    }
  };

  return (
    <div>
      <MDBCard>
        <MDBCardBody>
          <h3 className="mb-5">Contact us</h3>
          <div className="row">
            <div className="col-lg-5">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d12094.57348593182!2d-74.00599512526003!3d40.72586666928451!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c2598f988156a9%3A0xd54629bdf9d61d68!2sBroadway-Lafayette%20St!5e0!3m2!1spl!2spl!4v1624523797308!5m2!1spl!2spl"
                className="w-100" // Adjust the width to take the full width of the column
                style={{ border: "0", height: "100%", width: "100%" }} // Set a fixed height for the map
                loading="lazy"
                title = "google map"
              ></iframe>
            </div>
            <div className="col-lg-7">
              <form>
                <div className="row">
                  <div className="col-md-9">
                    <Form>
                      <Form.Group
                        className="mb-3"
                        controlId="exampleForm.ControlInput1"
                      >
                        <Form.Label>Enter the First Name</Form.Label>
                        <Form.Control
                          type="name"
                          placeholder="Enter Name"
                          autoFocus
                          onChange={(event) => {
                            setFirstName(event.target.value);
                          }}
                        />
                        <Form.Group
                          className="mb-3"
                          controlId="exampleForm.ControlInput1"
                        >
                          <Form.Label>Enter the middle Name</Form.Label>
                          <Form.Control
                            type="name"
                            placeholder="Enter the Middle Name"
                            onChange={(event) => {
                              setMiddleName(event.target.value);
                            }}
                          />
                        </Form.Group>
                        <Form.Group
                          className="mb-3"
                          controlId="exampleForm.ControlInput1"
                        >
                          <Form.Label>Enter the Last Name</Form.Label>
                          <Form.Control
                            type="name"
                            placeholder="Enter the Last Name"
                            onChange={(event) => {
                              setLastName(event.target.value);
                            }}
                          />
                        </Form.Group>
                      </Form.Group>
                      <Form.Group
                        className="mb-3"
                        controlId="exampleForm.ControlInput1"
                      >
                        <Form.Label>Email address</Form.Label>
                        <Form.Control
                          type="email"
                          placeholder="name@example.com"
                          onChange={(event) => {
                            setEmail(event.target.value);
                          }}
                        />
                      </Form.Group>
                      <Form.Group
                        className="mb-3"
                        controlId="exampleForm.ControlTextarea1"
                      >
                        <Form.Label>description</Form.Label>
                        <Form.Control
                          as="textarea"
                          rows={3}
                          onChange={(event) => {
                            setDiscription(event.target.value);
                          }}
                        />
                      </Form.Group>
                    </Form>
                    <Button variant="primary" onClick={insert}>
                      Send.
                    </Button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </MDBCardBody>
      </MDBCard>
      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Enter details</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
              <Form.Label>Enter the First Name</Form.Label>
              <Form.Control
                type="name"
                placeholder="Enter Name"
                autoFocus
                onChange={(event) => {
                  setFirstName(event.target.value);
                }}
              />
              <Form.Group
                className="mb-3"
                controlId="exampleForm.ControlInput1"
              >
                <Form.Label>Enter the middle Name</Form.Label>
                <Form.Control
                  type="name"
                  placeholder="Enter the Middle Name"
                  onChange={(event) => {
                    setMiddleName(event.target.value);
                  }}
                />
              </Form.Group>
              <Form.Group
                className="mb-3"
                controlId="exampleForm.ControlInput1"
              >
                <Form.Label>Enter the Last Name</Form.Label>
                <Form.Control
                  type="name"
                  placeholder="Enter the Last Name"
                  onChange={(event) => {
                    setLastName(event.target.value);
                  }}
                />
              </Form.Group>
            </Form.Group>
            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
              <Form.Label>Email address</Form.Label>
              <Form.Control
                type="email"
                placeholder="name@example.com"
                onChange={(event) => {
                  setEmail(event.target.value);
                }}
              />
            </Form.Group>
            <Form.Group
              className="mb-3"
              controlId="exampleForm.ControlTextarea1"
            >
              <Form.Label>description</Form.Label>
              <Form.Control
                as="textarea"
                rows={3}
                onChange={(event) => {
                  setDiscription(event.target.value);
                }}
              />
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" onClick={insert}>
            Send.
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
}
