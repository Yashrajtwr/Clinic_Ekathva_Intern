import React from 'react';
import {
  MDBFooter,
  MDBContainer,
  MDBBtn
} from 'mdb-react-ui-kit';
import { Link } from "react-router-dom";
export default function Fotter() {
  return (
    <MDBFooter className='text-center text-white' bgColor='primary'>
      <MDBContainer className='p-4 pb-0'>
        <section className=''>
        <p
            style={{
              fontSize: "20px",
              color: "white",
              fontFamily: "Montserrat",
              marginLeft: "10%",
              marginRight: "10%",
              textAlign: "center",
            }}
          >
            <span className='me-3'>Register for free</span>
            <MDBBtn type='button' outline color="light" as = {Link} to = "/SignUpPage">
              Sign up!
            </MDBBtn>
          </p>
        </section>
      </MDBContainer>

      <div className='text-center p-3' style={{ backgroundColor: 'rgba(0, 0, 0, 0.2)' }}>
        © 2020 Copyright:
      Ekathva Clinic

      </div>
    </MDBFooter>
  );
}