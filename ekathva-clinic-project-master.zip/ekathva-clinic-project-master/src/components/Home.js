import React from "react";
import Carousel from 'react-bootstrap/Carousel';

function Home() {
  return (
    <>
    <div classNameN="hero">
    <style>
        {`
          /* For desktop screens */
          @media (min-width: 768px) {
            .carousel-item img {
              height: 700px; /* Adjust the height for desktop */
              object-fit: cover;
            }
          }

          /* For smaller screens like mobile */
          @media (max-width: 767px) {
            .carousel-item img {
              height: 300px; /* Adjust the height for mobile */
              object-fit: cover;
            }
          }
        `}
      </style>
     <Carousel variant="dark">
      <Carousel.Item>
        <img
          className="d-block w-100"
          src="/helth_image/nh1.jpg"
          alt="First slide"
      
        />
        <Carousel.Caption>
      
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
        <img
          className="d-block w-100"
          src="/helth_image/nh2.jpg"
          alt="Second slide"
        
        />
        <Carousel.Caption>
         
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
        <img
          className="d-block w-100"
          src="/helth_image/h2.jpg"
          alt="Third slide"
         
        />
        <Carousel.Caption>
          
         
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
        <img
          className="d-block w-100"
          src="/image/h2.jpg"
          alt="Third slide"
         
        />
        <Carousel.Caption>
       
        </Carousel.Caption>
      </Carousel.Item>
      
      <Carousel.Item>
        <img
          className="d-block w-100"
          src="/image/h1.jpg"
          alt="Third slide"
         
        />
        <Carousel.Caption>
         
          
        </Carousel.Caption>
      </Carousel.Item>
    </Carousel>
   
    </div>

    </>
  );
}
export default Home;
