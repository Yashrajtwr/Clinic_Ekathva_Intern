import React from "react";

export default function S() {
  return (
    <div>
      <div class="card" >
        <div class="card-header">Log In Page</div>
        <div class="card-body">
          <h5 class="card-title">LogIN</h5>
          <p class="card-text">
            With supporting text below as a natural lead-in to additional
            content.
          </p>
          <div class="input-group mb-3">
  <div class="input-group-text">
    <input class="form-check-input mt-0" type="checkbox" value="" aria-label="Checkbox for following text input"/>
  </div>
  <input type="text" class="form-control" aria-label="Text input with checkbox"/>
</div>

<div class="input-group mb-3">
  <div class="input-group-text">
    <input class="form-check-input mt-0" type="checkbox" value="" aria-label="Checkbox for following text input"/>
  </div>
  <input type="text" class="form-control" aria-label="Text input with checkbox"/>
</div>

<div class="input-group">
  <div class="input-group-text">
    <input class="form-check-input mt-0" type="radio" value="" aria-label="Radio button for following text input"/>
  </div>
  <input type="text" class="form-control" aria-label="Text input with radio button"/>
</div>
<br></br>
<button type="button" class="btn btn-primary">Primary</button>
        </div>
      </div>
    </div>
  );
}
