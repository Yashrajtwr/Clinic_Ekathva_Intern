import React from "react";
import { useState, useEffect } from "react";
import { db } from "./Database";
import { collection, getDocs } from "firebase/firestore";

function UsersTable() {
  const [users, setUsers] = useState([]);
  const sign_data = collection(db, "SignUpNew");

  useEffect(() => {
    const getUsers = async () => {
      const data = await getDocs(sign_data);
      setUsers(data.docs.map((doc) => ({ ...doc.data(), id: doc.id })));
    };
    getUsers();
  }, [sign_data]);
  return (
    <div class="card  text-center info ">
      <div class="card-header">Users SignUp Data</div>
      <div class="card-body ">
        <div className="table">
          <>
            <div class="table-responsive table-wrapper-scroll-y my-custom-scrollbar ">
              <table class="table ">
                <tr>
                  <th scope="col">First Name</th>
                  <th scope="col">Middle Name</th>
                  <th scope="col">Last Name</th>
                  <th scope="col">Gender</th>
                  <th scope="col">Email</th>
                  <th scope="col">Password</th>
                  <th scope="col">description</th>
                  <th scope="col">Edit</th>
                  <th scope="col">Delete</th>
                </tr>
                {""}
                {users.map((SignUp) => {
                  return (
                    <tbody>
                      <tr>
                        <td>{SignUp.first_name}</td>
                        <td>{SignUp.middle_name}</td>
                        <td>{SignUp.last_name}</td>
                        <td>{SignUp.gender}</td>
                        <td>{SignUp.email}</td>
                        <td>{SignUp.password}</td>
                        <td>{SignUp.conform}</td>
                        <td>
                          <button type="button" class="btn btn-primary">
                            Edit{" "}
                          </button>
                        </td>
                        <td>
                          <button type="button" class="btn btn-danger">
                            Delete
                          </button>
                        </td>
                      </tr>
                    </tbody>
                  );
                })}
              </table>
            </div>
          </>
        </div>
      </div>
      <div class="card-footer text-muted">2 days ago</div>
    </div>
  );
}

export default UsersTable;
