import React from "react";

import Col from 'react-bootstrap/Col';
import Form from 'react-bootstrap/Form';

import Row from 'react-bootstrap/Row';
export default function BiochemistryRequisitionForm() {
  return (
    <div>
      <div class="card text-center info">
        <div class="card-header">Biochemistry Requisition Form</div>
        
        <div class="card-body">
         
          <div class="card w-100">
  <div class="card-body">
    <h5 class="card-title">EKATHVA HOSPITAL AND RESEARCH CENTERE</h5>
    <h6 class="card-title">NH13 NAVLE MAIN ROAD, SHIVAMOGGA, KARNATAKA PH: 08181-2992640</h6>
    
  </div>
</div>

<div class="card w-100">
  <div class="card-body">
  <Form>
      <Row className="align-items-center">
        <Col sm={3} className="my-1">
        <div class="input-group flex-nowrap">
  <span class="input-group-text" id="addon-wrapping">Patient's Name</span>
  <input type="text" class="form-control" placeholder="Patient's Name" aria-label="Username" aria-describedby="addon-wrapping"/>
</div>
        </Col>
        <Col sm={3} className="my-1">
        <div class="input-group">
  <span class="input-group-text" id="addon-wrapping">Age and Sex</span>
  <input type="text" class="form-control" placeholder="" aria-label="Username" aria-describedby="addon-wrapping"/>
</div>
        </Col>
        <Col xs="auto" className="my-1">
        <div class="input-group">
  <span class="input-group-text" id="addon-wrapping">Ref. by Dr.</span>
  <input type="text" class="form-control" placeholder="Ref. by Dr." aria-label="Username" aria-describedby="addon-wrapping"/>
</div>
        </Col>
        
      </Row>



      <Row className="align-items-center">
        <Col sm={3} className="my-1">
        <div class="input-group flex-nowrap">
  <span class="input-group-text" id="addon-wrapping">Lab No</span>
  <input type="text" class="form-control" placeholder="Lab No" aria-label="Username" aria-describedby="addon-wrapping"/>
</div>
        </Col>
        <Col sm={3} className="my-1">
        <div class="input-group">
  <span class="input-group-text" id="addon-wrapping">Bill No</span>
  <input type="text" class="form-control" placeholder="Bill No" aria-label="Username" aria-describedby="addon-wrapping"/>
</div>
        </Col>
        <Col xs="auto" className="my-1">
        <div class="input-group">
  <span class="input-group-text" id="addon-wrapping">Date</span>
  <input type="text" class="form-control" placeholder="Ref. by Dr." aria-label="Username" aria-describedby="addon-wrapping"/>
</div>
        </Col>
        
      </Row>
    </Form>
  </div>
</div>
          
        </div>
        <div class="card-footer text-muted">2 days ago</div>
      </div>
    </div>
  );
}
