import "./App.css";
import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import UsersTable from "./components/UsersTable";
import LogInPage from "./components/LogInPage";
import NavigationBar from "./components/NavigationBar";
import UsersReg from "./components/UsersReg";
import Home from "./components/Home";
import Footer from "./components/Footer";
import Docters from "./components/Docters";
import ContactUs1 from "./components/ContactUs1";
import Review from "./components/Review";
import MainHomePage from "./components/MainHomePage";
import SignUpPage from "./components/SignUpPage";
import AdminLogInPage from "./components/AdminLoginPage";
import ShortStory from "./components/ShortStory";
import HomePage from "./components/HomePage";
import AboutPage from "./components/AboutPage";
import Specialities1 from "./components/Specialities1";
import AdminPage from "./components/AdminPage";
import Services from "./components/Services";
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import AdminMainPage from "./components/AdminMainPage";
import '../node_modules/bootstrap/dist/css/bootstrap.min.css'
import S from "./components/S";

import BiochemistryRequisitionForm from "./components/BiochemistryRequisitionForm";
import Contact from "./components/Contact";
import CardCarousel from "./components/CardCarousel";
import CentreofExcellence from "./components/CentreofExcellence";
import CancerCarePage from "./components/CancerCarePage";
import Blog from "./components/Blog";
import HealthyHeart from "./components/BlogComponent/HealthyHeart";
import PlasticSer from "./components/BlogComponent/PlasticSer";
import OralHygiene from "./components/BlogComponent/ OralHygiene";
import DentalHealth from "./components/BlogComponent/DentalHealth";
import PatientMainPage from "./components/PatientMainPage"
import PatientReg from "./components/PatientReg"
function App() {
  return (
    <Router>

     <NavigationBar />
    
      
      <Home />
      {/* <AddDocter/> */}
      {/* <AdminMainPage/> */}
      <CardCarousel/>
      {/* <CentreofExcellence/> */}
     
      <HomePage/> 
      {/* <AdminMainPage/>
     <PatientMainPage/> */}
      {/* <BiochemistryRequisitionForm/> */}
      <ToastContainer position="top-center"/>
      <Routes>
        <Route path="/BiochemistryRequisitionForm" element={<BiochemistryRequisitionForm/>}/>
       
        <Route path="/AdminMainPage" element={< AdminMainPage/>}/>
        <Route path="/S" element={< S/>}/>
        <Route path="/Services" element={<Services/>}/>
        <Route path="/AdminPage" element={<AdminPage/>}/>
        <Route path="/Specialities1" element={<Specialities1 />} />
        <Route path="/AboutPage" element={<AboutPage/>}/>
        <Route path="/ContactUs1" element={<ContactUs1/>}/>
        
        <Route path="/ShortStory" element={<ShortStory/>}/>
        <Route path="/about" element={<about />} />
        <Route path="/" element={<MainHomePage />} />
        <Route path="/Docters" element={<Docters />} />
        <Route path="/Review" element={<Review />} />
        <Route path="/UsersReg" element={<UsersReg />} />
        <Route path="/SignUpPage" element={<SignUpPage />} />
        <Route path="/LogInPage" element={<LogInPage />} />
        <Route path="/UsersTable" element={<UsersTable />} />
        <Route path="/AdminLogInPage" element={<AdminLogInPage />} />
        <Route path="/Contact" element={<Contact />}/>
        <Route path="/CentreofExcellence" element={<CentreofExcellence />}/>
        <Route path="/CancerCarePage" element={<CancerCarePage />}/>
        <Route path="/Blog" element={<Blog />}/>
        <Route path="/HealthyHeart" element = {<HealthyHeart/>}/>
        <Route path="/PlasticSer" element = {<PlasticSer/>}/>
        <Route path="/OralHygiene" element = {<OralHygiene/>}/>
        <Route path="/DentalHealth" element = {<DentalHealth/>}/>
        <Route path="/PatientMainPage" element = {<PatientMainPage/>}/>
        <Route path="/PatientReg" element = {<PatientReg/>}/>
      </Routes>
      <Blog/> 
   <Footer />

    </Router>
  );
}

export default App;